const manifest = (() => {
function __memo(fn) {
	let value;
	return () => value ??= (value = fn());
}

return {
	appDir: "_app",
	appPath: "_app",
	assets: new Set([".DS_Store","faltaporhacer.md","favicon.ico","favicon.png","logo.png","sounds/notification.mp3","ssl/ssl/cert.pem","ssl/ssl/key.pem"]),
	mimeTypes: {".md":"text/markdown",".png":"image/png",".mp3":"audio/mpeg"},
	_: {
		client: {"start":"_app/immutable/entry/start.BbI-yONu.js","app":"_app/immutable/entry/app.B-MAuV3d.js","imports":["_app/immutable/entry/start.BbI-yONu.js","_app/immutable/chunks/entry.DE6h7fMi.js","_app/immutable/chunks/runtime.CYoiLdmP.js","_app/immutable/entry/app.B-MAuV3d.js","_app/immutable/chunks/preload-helper.B5Jg7y3B.js","_app/immutable/chunks/runtime.CYoiLdmP.js","_app/immutable/chunks/render.B8Gi3m-6.js","_app/immutable/chunks/events.D_Kh9_Cj.js","_app/immutable/chunks/disclose-version.CBbrbG3j.js","_app/immutable/chunks/if.DM2tvzsw.js","_app/immutable/chunks/proxy.B8xqnh-n.js","_app/immutable/chunks/props.CW_e8doA.js","_app/immutable/chunks/index-client.CX9LO-Jo.js"],"stylesheets":[],"fonts":[],"uses_env_dynamic_public":false},
		nodes: [
			__memo(() => import('./chunks/0-DV9Sizin.js')),
			__memo(() => import('./chunks/1-B7ggJbiG.js')),
			__memo(() => import('./chunks/2-C9inIPSo.js')),
			__memo(() => import('./chunks/3-tUcc48QF.js')),
			__memo(() => import('./chunks/4-wq3x3ntq.js')),
			__memo(() => import('./chunks/5-Cu7WaHqa.js')),
			__memo(() => import('./chunks/6-CPSnCfDw.js')),
			__memo(() => import('./chunks/7-C2oKedM1.js')),
			__memo(() => import('./chunks/8-DdDm9Qe_.js')),
			__memo(() => import('./chunks/9-DnhNzGmx.js')),
			__memo(() => import('./chunks/10-BzG1gAaO.js')),
			__memo(() => import('./chunks/11-CmwV3fFS.js')),
			__memo(() => import('./chunks/12-DS1SGnGO.js')),
			__memo(() => import('./chunks/13-C4ex8hA6.js')),
			__memo(() => import('./chunks/14-I98Fnurd.js')),
			__memo(() => import('./chunks/15-BVtXgSHv.js')),
			__memo(() => import('./chunks/16-Czz_Gds8.js')),
			__memo(() => import('./chunks/17-CYLm14cW.js')),
			__memo(() => import('./chunks/18-Cl4L3Jlx.js')),
			__memo(() => import('./chunks/19-orf32oq2.js'))
		],
		routes: [
			{
				id: "/",
				pattern: /^\/$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 4 },
				endpoint: null
			},
			{
				id: "/admin/dashboard",
				pattern: /^\/admin\/dashboard\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 10 },
				endpoint: null
			},
			{
				id: "/admin/historial-pagos",
				pattern: /^\/admin\/historial-pagos\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 11 },
				endpoint: null
			},
			{
				id: "/admin/login",
				pattern: /^\/admin\/login\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 12 },
				endpoint: null
			},
			{
				id: "/admin/reportes-cajeros",
				pattern: /^\/admin\/reportes-cajeros\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 14 },
				endpoint: null
			},
			{
				id: "/admin/reportes-clientes",
				pattern: /^\/admin\/reportes-clientes\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 15 },
				endpoint: __memo(() => import('./chunks/_server.ts-CKUgjnml.js'))
			},
			{
				id: "/admin/reportes",
				pattern: /^\/admin\/reportes\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 13 },
				endpoint: __memo(() => import('./chunks/_server.ts-D7y0WbYf.js'))
			},
			{
				id: "/admin/validar-pagos",
				pattern: /^\/admin\/validar-pagos\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 16 },
				endpoint: null
			},
			{
				id: "/admin/validar-reporte",
				pattern: /^\/admin\/validar-reporte\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./chunks/_server.ts-CUiC0wQd.js'))
			},
			{
				id: "/api/admin/dashboard",
				pattern: /^\/api\/admin\/dashboard\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./chunks/_server.ts-BD4__QD3.js'))
			},
			{
				id: "/api/admin/egresos",
				pattern: /^\/api\/admin\/egresos\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./chunks/_server.ts-Ba4lfmVL.js'))
			},
			{
				id: "/api/admin/historial",
				pattern: /^\/api\/admin\/historial\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./chunks/_server.ts-2CPCsjFk.js'))
			},
			{
				id: "/api/admin/ingresos",
				pattern: /^\/api\/admin\/ingresos\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./chunks/_server.ts-DHC-WZJL.js'))
			},
			{
				id: "/api/admin/login",
				pattern: /^\/api\/admin\/login\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./chunks/_server.ts-BVsPFDkT.js'))
			},
			{
				id: "/api/admin/logout",
				pattern: /^\/api\/admin\/logout\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./chunks/_server.ts-y1-znJUk.js'))
			},
			{
				id: "/api/admin/reportes-cajero",
				pattern: /^\/api\/admin\/reportes-cajero\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./chunks/_server.ts-xrSQ25iV.js'))
			},
			{
				id: "/api/admin/reportes-clientes",
				pattern: /^\/api\/admin\/reportes-clientes\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./chunks/_server.ts-4rS3uJ2U.js'))
			},
			{
				id: "/api/admin/reportes",
				pattern: /^\/api\/admin\/reportes\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./chunks/_server.ts-DVFtVR1C.js'))
			},
			{
				id: "/api/admin/validar-pago",
				pattern: /^\/api\/admin\/validar-pago\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./chunks/_server.ts-I9eWkm2L.js'))
			},
			{
				id: "/api/admin/validar-reporte",
				pattern: /^\/api\/admin\/validar-reporte\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./chunks/_server.ts-BlQZDkJO.js'))
			},
			{
				id: "/api/auth",
				pattern: /^\/api\/auth\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./chunks/_server.ts-xIMa5Sqt.js'))
			},
			{
				id: "/api/auth/logout",
				pattern: /^\/api\/auth\/logout\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./chunks/_server.ts-DVqf-cpw.js'))
			},
			{
				id: "/api/caja/cierre",
				pattern: /^\/api\/caja\/cierre\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./chunks/_server.ts-CtTKxaoT.js'))
			},
			{
				id: "/api/caja/monto",
				pattern: /^\/api\/caja\/monto\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./chunks/_server.ts-fbtpW10U.js'))
			},
			{
				id: "/api/cajeros/historial",
				pattern: /^\/api\/cajeros\/historial\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./chunks/_server.ts-DXEdb2a3.js'))
			},
			{
				id: "/api/cajeros/recibos",
				pattern: /^\/api\/cajeros\/recibos\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./chunks/_server.ts-F0wwNPO_.js'))
			},
			{
				id: "/api/cajeros/reportes",
				pattern: /^\/api\/cajeros\/reportes\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./chunks/_server.ts-DE77fmPA.js'))
			},
			{
				id: "/api/clientes",
				pattern: /^\/api\/clientes\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./chunks/_server.ts-N_Ct2TQM.js'))
			},
			{
				id: "/api/consultar-cliente",
				pattern: /^\/api\/consultar-cliente\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./chunks/_server.ts-UGQQCXd_.js'))
			},
			{
				id: "/api/consultar-cliente/historial",
				pattern: /^\/api\/consultar-cliente\/historial\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./chunks/_server.ts-C_2PzDFK.js'))
			},
			{
				id: "/api/exchange-rate",
				pattern: /^\/api\/exchange-rate\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./chunks/_server.ts-DIEXCSSk.js'))
			},
			{
				id: "/api/generar-reporte",
				pattern: /^\/api\/generar-reporte\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./chunks/_server.ts-B56yK-s2.js'))
			},
			{
				id: "/api/historial",
				pattern: /^\/api\/historial\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./chunks/_server.ts-DVJixwKt.js'))
			},
			{
				id: "/api/operaciones",
				pattern: /^\/api\/operaciones\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./chunks/_server.ts-DqOapm5d.js'))
			},
			{
				id: "/api/pagos/efectivo",
				pattern: /^\/api\/pagos\/efectivo\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./chunks/_server.ts-Cb4kcj0o.js'))
			},
			{
				id: "/api/pagos/procesar-pago",
				pattern: /^\/api\/pagos\/procesar-pago\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./chunks/_server.ts-BQscYnaw.js'))
			},
			{
				id: "/api/pagos/reportes",
				pattern: /^\/api\/pagos\/reportes\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./chunks/_server.ts-C3nKipVP.js'))
			},
			{
				id: "/api/pagos/validar",
				pattern: /^\/api\/pagos\/validar\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./chunks/_server.ts-Dkq9Ce3l.js'))
			},
			{
				id: "/api/payments",
				pattern: /^\/api\/payments\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./chunks/_server.ts-CvbO_ala.js'))
			},
			{
				id: "/api/payments/external",
				pattern: /^\/api\/payments\/external\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./chunks/_server.ts-DehkgS2t.js'))
			},
			{
				id: "/api/proxy",
				pattern: /^\/api\/proxy\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./chunks/_server.ts-SAZKnwPh.js'))
			},
			{
				id: "/api/receipts",
				pattern: /^\/api\/receipts\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./chunks/_server.ts-Dfwu9qPT.js'))
			},
			{
				id: "/api/recibos",
				pattern: /^\/api\/recibos\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./chunks/_server.ts-DEfnmUHh.js'))
			},
			{
				id: "/api/reportar-pago",
				pattern: /^\/api\/reportar-pago\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./chunks/_server.ts-Bfh8EC1r.js'))
			},
			{
				id: "/api/reportes",
				pattern: /^\/api\/reportes\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./chunks/_server.ts-cn5ewjC7.js'))
			},
			{
				id: "/api/users",
				pattern: /^\/api\/users\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./chunks/_server.ts-B5h_W_9N.js'))
			},
			{
				id: "/api/validar-reporte",
				pattern: /^\/api\/validar-reporte\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./chunks/_server.ts-BMjGrfBv.js'))
			},
			{
				id: "/login",
				pattern: /^\/login\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 17 },
				endpoint: null
			},
			{
				id: "/logout",
				pattern: /^\/logout\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 18 },
				endpoint: __memo(() => import('./chunks/_server.ts-BdXEt0DZ.js'))
			},
			{
				id: "/web",
				pattern: /^\/web\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 19 },
				endpoint: null
			},
			{
				id: "/[cajero]/dashboard",
				pattern: /^\/([^/]+?)\/dashboard\/?$/,
				params: [{"name":"cajero","optional":false,"rest":false,"chained":false}],
				page: { layouts: [0,2,3,], errors: [1,,,], leaf: 5 },
				endpoint: null
			},
			{
				id: "/[cajero]/historial",
				pattern: /^\/([^/]+?)\/historial\/?$/,
				params: [{"name":"cajero","optional":false,"rest":false,"chained":false}],
				page: { layouts: [0,2,], errors: [1,,], leaf: 6 },
				endpoint: null
			},
			{
				id: "/[cajero]/pagos",
				pattern: /^\/([^/]+?)\/pagos\/?$/,
				params: [{"name":"cajero","optional":false,"rest":false,"chained":false}],
				page: { layouts: [0,2,], errors: [1,,], leaf: 7 },
				endpoint: null
			},
			{
				id: "/[cajero]/recibos",
				pattern: /^\/([^/]+?)\/recibos\/?$/,
				params: [{"name":"cajero","optional":false,"rest":false,"chained":false}],
				page: { layouts: [0,2,], errors: [1,,], leaf: 8 },
				endpoint: null
			},
			{
				id: "/[cajero]/reportes",
				pattern: /^\/([^/]+?)\/reportes\/?$/,
				params: [{"name":"cajero","optional":false,"rest":false,"chained":false}],
				page: { layouts: [0,2,], errors: [1,,], leaf: 9 },
				endpoint: null
			}
		],
		matchers: async () => {
			
			return {  };
		},
		server_assets: {}
	}
}
})();

const prerendered = new Set([]);

const base = "";

export { base, manifest, prerendered };
//# sourceMappingURL=manifest.js.map
