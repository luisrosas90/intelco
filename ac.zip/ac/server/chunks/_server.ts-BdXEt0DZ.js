import { j as json } from './index-DHSpIlkf.js';

const POST = async ({ cookies }) => {
  cookies.delete("session", { path: "/" });
  return json({ success: true });
};

export { POST };
//# sourceMappingURL=_server.ts-BdXEt0DZ.js.map
