import { q as ensure_array_like, h as escape_html, e as pop, t as current_component, p as push } from './index2-aFjvJk03.js';

function onDestroy(fn) {
  var context = (
    /** @type {Component} */
    current_component
  );
  (context.d ??= []).push(fn);
}
function _page($$payload, $$props) {
  push();
  let reportesPendientes = [];
  let intervaloAutoRefresh;
  onDestroy(() => {
    clearInterval(intervaloAutoRefresh);
  });
  $$payload.out += `<section><h1>Reportes Pendientes de Validación</h1> `;
  {
    $$payload.out += "<!--[!-->";
  }
  $$payload.out += `<!--]--> `;
  if (reportesPendientes.length > 0) {
    $$payload.out += "<!--[-->";
    const each_array = ensure_array_like(reportesPendientes);
    $$payload.out += `<ul class="svelte-10dqy8e"><!--[-->`;
    for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
      const reporte = each_array[$$index];
      $$payload.out += `<li class="mb-4 p-4 bg-gray-100 border border-gray-300 rounded svelte-10dqy8e"><p><strong>Cliente ID:</strong> ${escape_html(reporte.cliente_id)}</p> <p><strong>Monto:</strong> ${escape_html(reporte.monto)} USD</p> <p><strong>Número de Teléfono:</strong> ${escape_html(reporte.telefono)}</p> <p><strong>Referencia de Pago:</strong> ${escape_html(reporte.referencia_pago)}</p> <p><strong>Banco Emisor:</strong> ${escape_html(reporte.banco)}</p> <p><strong>ID Factura:</strong> ${escape_html(reporte.factura_id)}</p> <button class="bg-blue-500 text-white px-4 py-2 rounded mt-2 svelte-10dqy8e">Validar Pago</button></li>`;
    }
    $$payload.out += `<!--]--></ul>`;
  } else {
    $$payload.out += "<!--[!-->";
    $$payload.out += `<p>No hay reportes pendientes de validación.</p>`;
  }
  $$payload.out += `<!--]--></section>`;
  pop();
}

export { _page as default };
//# sourceMappingURL=_page.svelte-BcmnZaqE.js.map
