import { l as attr, e as pop, p as push } from './index2-aFjvJk03.js';
import './client-BUusD8wq.js';
import './exports-BGi7-Rnc.js';

function _page($$payload, $$props) {
  push();
  let email = "";
  let password = "";
  $$payload.out += `<form class="svelte-1h83v9i"><div class="svelte-1h83v9i"><label for="email" class="svelte-1h83v9i">Correo electrónico:</label> <input type="email" id="email"${attr("value", email)} required class="svelte-1h83v9i"></div> <div class="svelte-1h83v9i"><label for="password" class="svelte-1h83v9i">Contraseña:</label> <input type="password" id="password"${attr("value", password)} required class="svelte-1h83v9i"></div> `;
  {
    $$payload.out += "<!--[!-->";
  }
  $$payload.out += `<!--]--> <button type="submit" class="svelte-1h83v9i">Iniciar sesión</button></form>`;
  pop();
}

export { _page as default };
//# sourceMappingURL=_page.svelte-CYJ882pi.js.map
