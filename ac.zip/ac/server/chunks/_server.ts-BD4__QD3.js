import { p as pool } from './db-DmdxKCrm.js';
import { j as json } from './index-DHSpIlkf.js';
import 'mysql2/promise';

const GET = async () => {
  try {
    const [clientes] = await pool.query("SELECT COUNT(*) AS totalClientes FROM clientes");
    const [reportesPendientes] = await pool.query('SELECT COUNT(*) AS totalReportesPendientes FROM reportes_pagos WHERE estado = "pendiente de validación"');
    const [cajeros] = await pool.query("SELECT COUNT(*) AS totalCajeros FROM cajeros");
    return json({
      success: true,
      totalClientes: clientes[0].totalClientes,
      totalReportesPendientes: reportesPendientes[0].totalReportesPendientes,
      totalCajeros: cajeros[0].totalCajeros
    });
  } catch (error) {
    console.error("Error fetching dashboard data:", error);
    return json({ success: false, message: "Error fetching dashboard data." }, { status: 500 });
  }
};

export { GET };
//# sourceMappingURL=_server.ts-BD4__QD3.js.map
