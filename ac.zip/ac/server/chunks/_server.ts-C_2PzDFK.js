import { j as json } from './index-DHSpIlkf.js';
import { p as pool } from './db-DmdxKCrm.js';
import 'mysql2/promise';

const POST = async ({ request }) => {
  try {
    const { clienteId, descripcion, monto, cajeroId } = await request.json();
    if (!clienteId || !descripcion || !monto) {
      return json({ success: false, message: "Todos los campos son obligatorios." }, { status: 400 });
    }
    const [result] = await pool.execute(
      "INSERT INTO historial (cliente_id, cajero_id, descripcion, monto) VALUES (?, ?, ?, ?)",
      [clienteId, cajeroId || null, descripcion, monto]
    );
    return json({ success: true, message: "Pago registrado en el historial", id: result.insertId });
  } catch (error) {
    console.error("Error al registrar el historial:", error);
    return json({ success: false, message: "Error al registrar el historial." }, { status: 500 });
  }
};

export { POST };
//# sourceMappingURL=_server.ts-C_2PzDFK.js.map
