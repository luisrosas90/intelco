import { q as ensure_array_like, h as escape_html } from './index2-aFjvJk03.js';

function _page($$payload) {
  let recibos = [];
  const each_array = ensure_array_like(recibos);
  $$payload.out += `<section><h2>Recibos del Cliente</h2> <input type="text" placeholder="Cédula"> <ul><!--[-->`;
  for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
    const recibo = each_array[$$index];
    $$payload.out += `<li>${escape_html(recibo.fecha)}: ${escape_html(recibo.monto)} - ${escape_html(recibo.status)}</li>`;
  }
  $$payload.out += `<!--]--></ul></section>`;
}

export { _page as default };
//# sourceMappingURL=_page.svelte-_PPxhJrJ.js.map
