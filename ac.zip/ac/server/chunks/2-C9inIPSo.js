import { r as redirect } from './index-DHSpIlkf.js';

function getUserRoleFromSession(session) {
  if (!session || !session.role) {
    console.warn('Sesión no válida o sin rol definido. Estableciendo el rol a "guest".');
    return "guest";
  }
  console.log("Rol de usuario encontrado en la sesión:", session.role);
  return session.role;
}
const load = async ({ cookies }) => {
  console.log("Verificando cookie de sesión...");
  const sessionCookie = cookies.get("session");
  if (!sessionCookie) {
    console.log("No se encontró cookie de sesión, redirigiendo a /login");
    throw redirect(303, "/login");
  }
  let session;
  try {
    console.log("Cookie de sesión encontrada:", sessionCookie);
    session = JSON.parse(sessionCookie);
  } catch (error) {
    console.error("Error al parsear la cookie de sesión:", error);
    throw redirect(303, "/login");
  }
  const userRole = getUserRoleFromSession(session);
  if (userRole !== "cajero") {
    console.error(`Rol inválido (${userRole}), redirigiendo a /login`);
    throw redirect(303, "/login");
  }
  console.log("Acceso permitido para el usuario:", session.user);
  return {
    user: session.user
    // Devolver el usuario de la sesión al layout
  };
};

var _layout_server_ts = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 2;
let component_cache;
const component = async () => component_cache ??= (await import('./_layout.svelte-Kzcm4X-Q.js')).default;
const server_id = "src/routes/[cajero]/+layout.server.ts";
const imports = ["_app/immutable/nodes/2.CNHMo4X3.js","_app/immutable/chunks/disclose-version.CBbrbG3j.js","_app/immutable/chunks/runtime.CYoiLdmP.js","_app/immutable/chunks/events.D_Kh9_Cj.js","_app/immutable/chunks/if.DM2tvzsw.js","_app/immutable/chunks/misc.BWz1Zf3L.js","_app/immutable/chunks/attributes.ERSpOZb7.js","_app/immutable/chunks/lifecycle.BoDPO5kt.js","_app/immutable/chunks/props.CW_e8doA.js","_app/immutable/chunks/proxy.B8xqnh-n.js","_app/immutable/chunks/entry.DE6h7fMi.js"];
const stylesheets = ["_app/immutable/assets/2.26vtim-6.css"];
const fonts = [];

export { component, fonts, imports, index, _layout_server_ts as server, server_id, stylesheets };
//# sourceMappingURL=2-C9inIPSo.js.map
