import { q as ensure_array_like, h as escape_html, e as pop, p as push } from './index2-aFjvJk03.js';

function _page($$payload, $$props) {
  push();
  let pagosPendientes = [];
  $$payload.out += `<section><h2>Validar Pagos Pendientes</h2> <ul>`;
  if (pagosPendientes.length > 0) {
    $$payload.out += "<!--[-->";
    const each_array = ensure_array_like(pagosPendientes);
    $$payload.out += `<!--[-->`;
    for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
      const pago = each_array[$$index];
      $$payload.out += `<li>${escape_html(pago.cliente)} - ${escape_html(pago.monto)} Bs <button>Validar</button></li>`;
    }
    $$payload.out += `<!--]-->`;
  } else {
    $$payload.out += "<!--[!-->";
    $$payload.out += `<p>No hay pagos pendientes.</p>`;
  }
  $$payload.out += `<!--]--></ul></section>`;
  pop();
}

export { _page as default };
//# sourceMappingURL=_page.svelte-BF5oqf5c.js.map
