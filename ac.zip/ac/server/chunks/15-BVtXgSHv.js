const index = 15;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-CpK8IA7K.js')).default;
const imports = ["_app/immutable/nodes/15.C23oy7ck.js","_app/immutable/chunks/disclose-version.CBbrbG3j.js","_app/immutable/chunks/runtime.CYoiLdmP.js","_app/immutable/chunks/render.B8Gi3m-6.js","_app/immutable/chunks/events.D_Kh9_Cj.js","_app/immutable/chunks/each.CwO15nsP.js","_app/immutable/chunks/lifecycle.BoDPO5kt.js","_app/immutable/chunks/index-client.CX9LO-Jo.js"];
const stylesheets = ["_app/immutable/assets/15.BhzUjSAT.css"];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=15-BVtXgSHv.js.map
