import { j as json } from './index-DHSpIlkf.js';
import { p as pool } from './db-DmdxKCrm.js';
import 'mysql2/promise';

const POST = async ({ request }) => {
  const { cliente_id, referencia_pago, monto } = await request.json();
  if (!cliente_id || !referencia_pago || !monto) {
    return json({ success: false, message: "Todos los campos son obligatorios." }, { status: 400 });
  }
  try {
    const [result] = await pool.execute(
      `INSERT INTO reportes_pendientes (cliente_id, referencia_pago, monto, estado) VALUES (?, ?, ?, 'pendiente')`,
      [cliente_id, referencia_pago, monto]
    );
    const insertId = result.insertId;
    if (!insertId) {
      throw new Error("Error al obtener el ID del reporte insertado");
    }
    return json({ success: true, reporteId: insertId });
  } catch (error) {
    console.error("Error al crear el reporte pendiente:", error);
    return json({ success: false, message: "Error al crear el reporte" });
  }
};

export { POST };
//# sourceMappingURL=_server.ts-BMjGrfBv.js.map
