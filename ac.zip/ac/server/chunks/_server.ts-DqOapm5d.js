import { p as pool } from './db-DmdxKCrm.js';
import { j as json } from './index-DHSpIlkf.js';
import 'mysql2/promise';

const POST = async ({ request }) => {
  try {
    const { clienteId, tipoOperacion, monto, motivo, fecha } = await request.json();
    if (!clienteId || !tipoOperacion || !monto || !motivo || !fecha) {
      return json({ message: "Faltan datos obligatorios" }, { status: 400 });
    }
    const [result] = await pool.execute(
      `INSERT INTO operaciones (cliente_id, tipo_operacion, monto, motivo, fecha)
       VALUES (?, ?, ?, ?, ?)`,
      [clienteId, tipoOperacion, monto, motivo, fecha]
    );
    return json({ message: "Operación insertada correctamente", operationId: result.insertId }, { status: 201 });
  } catch (error) {
    console.error("Error al insertar la operación:", error);
    return json({ message: "Error al insertar la operación" }, { status: 500 });
  }
};

export { POST };
//# sourceMappingURL=_server.ts-DqOapm5d.js.map
