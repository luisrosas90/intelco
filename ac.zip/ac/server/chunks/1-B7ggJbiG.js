const index = 1;
let component_cache;
const component = async () => component_cache ??= (await import('./error.svelte-D8NqtwF0.js')).default;
const imports = ["_app/immutable/nodes/1.Bm8F9Jd3.js","_app/immutable/chunks/disclose-version.CBbrbG3j.js","_app/immutable/chunks/runtime.CYoiLdmP.js","_app/immutable/chunks/render.B8Gi3m-6.js","_app/immutable/chunks/events.D_Kh9_Cj.js","_app/immutable/chunks/lifecycle.BoDPO5kt.js","_app/immutable/chunks/entry.DE6h7fMi.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=1-B7ggJbiG.js.map
