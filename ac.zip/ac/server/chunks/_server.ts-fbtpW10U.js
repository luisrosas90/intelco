import { j as json } from './index-DHSpIlkf.js';

async function obtenerMontoDeCaja(cajero_id) {
  console.log("Obteniendo el monto de la caja para cajero_id:", cajero_id);
  return 1e3;
}
const GET = async ({ url }) => {
  try {
    const cajero_id = url.searchParams.get("cajero_id");
    if (!cajero_id) {
      return json({ error: "No se proporcionó un ID de cajero." }, { status: 400 });
    }
    const monto = await obtenerMontoDeCaja(cajero_id);
    return json({ monto });
  } catch (error) {
    console.error("Error al obtener el monto de caja:", error);
    return json({ error: "Hubo un problema al obtener el monto de caja." }, { status: 500 });
  }
};

export { GET };
//# sourceMappingURL=_server.ts-fbtpW10U.js.map
