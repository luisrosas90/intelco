import { q as ensure_array_like, h as escape_html, e as pop, p as push } from './index2-aFjvJk03.js';

function _page($$payload, $$props) {
  push();
  let historial = [];
  $$payload.out += `<section><h2>Historial de Operaciones</h2> `;
  {
    $$payload.out += "<!--[!-->";
  }
  $$payload.out += `<!--]--> `;
  if (historial.length > 0) {
    $$payload.out += "<!--[-->";
    const each_array = ensure_array_like(historial);
    $$payload.out += `<ul><!--[-->`;
    for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
      const operacion = each_array[$$index];
      $$payload.out += `<li>${escape_html(operacion.tipo_operacion)}: ${escape_html(operacion.monto)} - ${escape_html(operacion.descripcion)} (${escape_html(new Date(operacion.fecha).toLocaleString())})</li>`;
    }
    $$payload.out += `<!--]--></ul>`;
  } else {
    $$payload.out += "<!--[!-->";
    $$payload.out += `<p>No hay operaciones registradas.</p>`;
  }
  $$payload.out += `<!--]--></section>`;
  pop();
}

export { _page as default };
//# sourceMappingURL=_page.svelte-BNbJIR_w.js.map
