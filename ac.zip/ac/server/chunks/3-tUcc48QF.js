import { r as redirect } from './index-DHSpIlkf.js';

const load = async ({ cookies }) => {
  const sessionCookie = cookies.get("session");
  if (!sessionCookie) {
    console.log("No se encontró cookie de sesión, redirigiendo a /login");
    throw redirect(303, "/login");
  }
  let session;
  try {
    session = JSON.parse(sessionCookie);
  } catch (error) {
    console.error("Error al parsear la cookie de sesión:", error);
    throw redirect(303, "/login");
  }
  if (!session || session.role !== "cajero") {
    throw redirect(303, "/login");
  }
  console.log("Acceso permitido para el usuario:", session.user);
  return {
    user: session.user
  };
};

var _layout_server_ts = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 3;
let component_cache;
const component = async () => component_cache ??= (await import('./_layout.svelte-TmvzKCwC.js')).default;
const server_id = "src/routes/[cajero]/dashboard/+layout.server.ts";
const imports = ["_app/immutable/nodes/3.DjMfN7oc.js","_app/immutable/chunks/disclose-version.CBbrbG3j.js","_app/immutable/chunks/runtime.CYoiLdmP.js","_app/immutable/chunks/render.B8Gi3m-6.js","_app/immutable/chunks/events.D_Kh9_Cj.js","_app/immutable/chunks/if.DM2tvzsw.js","_app/immutable/chunks/misc.BWz1Zf3L.js","_app/immutable/chunks/lifecycle.BoDPO5kt.js","_app/immutable/chunks/props.CW_e8doA.js","_app/immutable/chunks/proxy.B8xqnh-n.js"];
const stylesheets = ["_app/immutable/assets/app.CLF7lq6g.css"];
const fonts = [];

export { component, fonts, imports, index, _layout_server_ts as server, server_id, stylesheets };
//# sourceMappingURL=3-tUcc48QF.js.map
