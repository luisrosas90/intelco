import { j as json } from './index-DHSpIlkf.js';
import { c as cajerosConfig } from './cajeros-Doed7Zjo.js';

const POST = async ({ request }) => {
  try {
    const { usuario, clave } = await request.json();
    const cajero = cajerosConfig[usuario];
    if (!cajero || cajero.clave !== clave) {
      return json({ message: "Credenciales incorrectas" }, { status: 403 });
    }
    const session = {
      user: cajero.usuario,
      token: cajero.token,
      role: "cajero"
    };
    return json({ message: "Autenticado", session }, { status: 200 });
  } catch (error) {
    console.error("Error en la autenticación:", error);
    return json({ message: "Error en el servidor" }, { status: 500 });
  }
};

export { POST };
//# sourceMappingURL=_server.ts-xIMa5Sqt.js.map
