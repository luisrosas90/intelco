import { h as escape_html, q as ensure_array_like, e as pop, p as push } from './index2-aFjvJk03.js';
import './client-BUusD8wq.js';
import './exports-BGi7-Rnc.js';

function _page($$payload, $$props) {
  push();
  let totalClientes = 0;
  let totalReportesPendientes = 0;
  let totalCajeros = 0;
  let cajerosData = [];
  $$payload.out += `<section class="dashboard svelte-rm74z5"><h1 class="text-3xl font-bold mb-6">Panel de Administración</h1> <button class="bg-red-600 text-white px-4 py-2 rounded hover:bg-red-500">Cerrar Sesión</button> `;
  {
    $$payload.out += "<!--[!-->";
  }
  $$payload.out += `<!--]--> <div class="stats-grid svelte-rm74z5"><div class="stat-item svelte-rm74z5"><h2 class="svelte-rm74z5">Total de Clientes</h2> <p>${escape_html(totalClientes)}</p></div> <div class="stat-item svelte-rm74z5"><h2 class="svelte-rm74z5">Reportes Pendientes</h2> <p>${escape_html(totalReportesPendientes)}</p></div> <div class="stat-item svelte-rm74z5"><h2 class="svelte-rm74z5">Total de Cajeros</h2> <p>${escape_html(totalCajeros)}</p></div></div> <section class="cajeros-section mt-6 svelte-rm74z5"><h2 class="text-2xl font-bold mb-4">Información de Cajeros</h2> `;
  if (cajerosData.length > 0) {
    $$payload.out += "<!--[-->";
    const each_array = ensure_array_like(cajerosData);
    $$payload.out += `<table class="cajeros-table w-full bg-white border-collapse border border-gray-300 svelte-rm74z5"><thead class="bg-gray-200"><tr><th class="border border-gray-300 p-2 svelte-rm74z5">Cajero</th><th class="border border-gray-300 p-2 svelte-rm74z5">Saldo Actual</th><th class="border border-gray-300 p-2 svelte-rm74z5">Ingresos Totales</th><th class="border border-gray-300 p-2 svelte-rm74z5">Egresos Totales</th><th class="border border-gray-300 p-2 svelte-rm74z5">Última Operación</th></tr></thead><tbody><!--[-->`;
    for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
      const cajero = each_array[$$index];
      $$payload.out += `<tr><td class="border border-gray-300 p-2 svelte-rm74z5">${escape_html(cajero.nombre)}</td><td class="border border-gray-300 p-2 svelte-rm74z5">${escape_html(cajero.saldoActual)}</td><td class="border border-gray-300 p-2 svelte-rm74z5">${escape_html(cajero.ingresosTotales)}</td><td class="border border-gray-300 p-2 svelte-rm74z5">${escape_html(cajero.egresosTotales)}</td><td class="border border-gray-300 p-2 svelte-rm74z5">${escape_html(cajero.ultimaOperacion)}</td></tr>`;
    }
    $$payload.out += `<!--]--></tbody></table>`;
  } else {
    $$payload.out += "<!--[!-->";
    $$payload.out += `<p>No se encontró información de cajeros.</p>`;
  }
  $$payload.out += `<!--]--></section></section>`;
  pop();
}

export { _page as default };
//# sourceMappingURL=_page.svelte-Cufebiov.js.map
