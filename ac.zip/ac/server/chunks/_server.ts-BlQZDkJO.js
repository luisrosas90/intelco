import { j as json } from './index-DHSpIlkf.js';
import { p as pool } from './db-DmdxKCrm.js';
import 'mysql2/promise';

async function procesarPagoConApiExterna(idFactura, monto, metodo) {
  const apiUrl = "https://billing.corpintelco.com/api/v1/PaidInvoice";
  const token = "Z0VYemthUURWVDRXTi9VL29pZG5yQT09";
  const body = {
    token,
    idfactura: idFactura,
    cantidad: monto,
    pasarela: metodo
    // Método de pago (Efectivo, Pago Móvil, Zelle)
  };
  try {
    const response = await fetch(apiUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body)
    });
    const data = await response.json();
    return data;
  } catch (error) {
    console.error("Error al llamar a la API externa:", error);
    throw new Error("Error al procesar el pago en la API externa.");
  }
}
const POST = async ({ request }) => {
  try {
    const { reporteId, accion } = await request.json();
    if (accion !== "validar") {
      return json({ success: false, message: "Acción no válida." }, { status: 400 });
    }
    const [reporte] = await pool.execute("SELECT * FROM reportes_pagos WHERE id = ?", [reporteId]);
    if (!reporte || reporte.length === 0) {
      return json({ success: false, message: "Reporte no encontrado." }, { status: 404 });
    }
    const pago = reporte[0];
    const apiResponse = await procesarPagoConApiExterna(pago.factura_id, pago.monto, pago.metodo_pago);
    if (apiResponse && apiResponse.estado === "exito") {
      await pool.execute("UPDATE reportes_pagos SET estado = ? WHERE id = ?", ["procesado", reporteId]);
      return json({ success: true, message: "Pago validado correctamente." });
    } else {
      return json({ success: false, message: "Error al procesar el pago en la API externa." }, { status: 500 });
    }
  } catch (error) {
    console.error("Error al validar el pago:", error);
    return json({ success: false, message: "Error al validar el pago." }, { status: 500 });
  }
};

export { POST };
//# sourceMappingURL=_server.ts-BlQZDkJO.js.map
