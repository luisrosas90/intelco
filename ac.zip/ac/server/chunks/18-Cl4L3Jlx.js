const index = 18;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-2Xe0r6OK.js')).default;
const imports = ["_app/immutable/nodes/18.cXfcuoYi.js","_app/immutable/chunks/disclose-version.CBbrbG3j.js","_app/immutable/chunks/runtime.CYoiLdmP.js","_app/immutable/chunks/lifecycle.BoDPO5kt.js","_app/immutable/chunks/entry.DE6h7fMi.js","_app/immutable/chunks/index-client.CX9LO-Jo.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=18-Cl4L3Jlx.js.map
