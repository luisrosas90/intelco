import { j as json } from './index-DHSpIlkf.js';
import { p as pool } from './db-DmdxKCrm.js';
import 'mysql2/promise';

const procesarPagoConApiExterna = async (idFactura, valor) => {
  const apiUrl = "https://billing.corpintelco.com/api/v1/PaidInvoice";
  const token = "Z0VYemthUURWVDRXTi9VL29pZG5yQT09";
  const body = {
    token,
    idfactura: idFactura,
    cantidad: valor,
    pasarela: "Pago Móvil"
    // Aquí puedes personalizar el método de pago según sea necesario
  };
  try {
    const response = await fetch(apiUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body)
    });
    const data = await response.json();
    return data;
  } catch (error) {
    console.error("Error al llamar a la API externa:", error);
    throw new Error("Error al procesar el pago en la API externa.");
  }
};
const POST = async ({ request }) => {
  try {
    const { idFactura, valor } = await request.json();
    console.log("Datos recibidos en el backend:", { idFactura, valor });
    if (!idFactura || !valor) {
      console.error("Error: Todos los campos son obligatorios.");
      return json({ success: false, message: "Todos los campos son obligatorios." }, { status: 400 });
    }
    const externalApiResponse = await procesarPagoConApiExterna(idFactura, valor);
    console.log("Respuesta de la API externa:", externalApiResponse);
    if (externalApiResponse.estado === "exito") {
      const [result] = await pool.execute(
        `UPDATE reportes_pagos SET estado = 'procesado' WHERE factura_id = ?`,
        // Cambié id_factura a factura_id
        [idFactura]
      );
      return json({ success: true, message: "Pago procesado correctamente." });
    } else {
      return json({ success: false, message: "Error al procesar el pago con la API externa." });
    }
  } catch (error) {
    console.error("Error en el backend al procesar el pago:", error);
    return json({ success: false, message: "Error al procesar el pago." }, { status: 500 });
  }
};

export { POST };
//# sourceMappingURL=_server.ts-BQscYnaw.js.map
