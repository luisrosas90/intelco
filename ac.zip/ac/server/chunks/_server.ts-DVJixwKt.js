import { p as pool } from './db-DmdxKCrm.js';
import { j as json } from './index-DHSpIlkf.js';
import 'mysql2/promise';

const GET = async ({ url, locals }) => {
  const cajero_id = locals.user?.id;
  if (!cajero_id) {
    return json({ success: false, message: "Cajero no autenticado." }, { status: 401 });
  }
  try {
    const [rows] = await pool.query(
      "SELECT * FROM historial WHERE cajero_id = ? ORDER BY fecha DESC",
      [cajero_id]
    );
    return json({ success: true, historial: rows });
  } catch (error) {
    console.error("Error al obtener el historial:", error);
    return json({ success: false, message: "Error al obtener el historial." }, { status: 500 });
  }
};

export { GET };
//# sourceMappingURL=_server.ts-DVJixwKt.js.map
