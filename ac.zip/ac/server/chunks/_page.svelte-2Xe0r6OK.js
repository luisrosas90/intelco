import { e as pop, p as push } from './index2-aFjvJk03.js';
import './client-BUusD8wq.js';
import './exports-BGi7-Rnc.js';

function _page($$payload, $$props) {
  push();
  $$payload.out += `<!---->// src/routes/logout/+page.svelte <p>Redirigiendo...</p>`;
  pop();
}

export { _page as default };
//# sourceMappingURL=_page.svelte-2Xe0r6OK.js.map
