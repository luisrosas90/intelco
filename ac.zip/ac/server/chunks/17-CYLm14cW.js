import { f as fail, r as redirect } from './index-DHSpIlkf.js';
import { c as cajerosConfig } from './cajeros-Doed7Zjo.js';

const actions = {
  default: async ({ request, cookies }) => {
    const formData = await request.formData();
    const usuario = formData.get("usuario");
    const clave = formData.get("clave");
    console.log("Usuario recibido:", usuario);
    console.log("Clave recibida:", clave);
    const cajero = cajerosConfig[usuario];
    if (!cajero || cajero.clave !== clave) {
      return fail(400, { error: "Usuario o clave incorrectos" });
    }
    const sessionData = JSON.stringify({
      user: cajero.usuario,
      token: cajero.token,
      role: "cajero"
    });
    cookies.set("session", sessionData, {
      path: "/",
      // Asegura que sea accesible desde toda la aplicación
      httpOnly: true,
      // Asegura que la cookie no sea accesible desde el cliente (solo servidor)
      sameSite: "strict",
      // Previene el envío de la cookie a otros sitios
      secure: false,
      // Solo en HTTPS en producción
      maxAge: 60 * 60 * 24
      // La cookie durará 24 horas
    });
    console.log("Cookie de sesión creada:", sessionData);
    throw redirect(303, `/${cajero.usuario}/dashboard`);
  }
};

var _page_server_ts = /*#__PURE__*/Object.freeze({
  __proto__: null,
  actions: actions
});

const index = 17;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-C8rNh-y-.js')).default;
const server_id = "src/routes/login/+page.server.ts";
const imports = ["_app/immutable/nodes/17.C8pOoOMm.js","_app/immutable/chunks/disclose-version.CBbrbG3j.js","_app/immutable/chunks/runtime.CYoiLdmP.js","_app/immutable/chunks/render.B8Gi3m-6.js","_app/immutable/chunks/events.D_Kh9_Cj.js","_app/immutable/chunks/if.DM2tvzsw.js","_app/immutable/chunks/attributes.ERSpOZb7.js","_app/immutable/chunks/input.BQSx1zKk.js","_app/immutable/chunks/event-modifiers.Dejc541Y.js"];
const stylesheets = ["_app/immutable/assets/app.CLF7lq6g.css"];
const fonts = [];

export { component, fonts, imports, index, _page_server_ts as server, server_id, stylesheets };
//# sourceMappingURL=17-CYLm14cW.js.map
