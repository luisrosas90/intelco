function _page($$payload) {
  $$payload.out += `<h1>Pagos</h1> <form method="POST"><div><label for="monto">Monto:</label> <input id="monto" name="monto" type="number" required></div> <button type="submit">Realizar Pago</button></form>`;
}

export { _page as default };
//# sourceMappingURL=_page.svelte-DqVUlBYC.js.map
