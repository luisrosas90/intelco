import { j as json } from './index-DHSpIlkf.js';

const POST = async ({ cookies }) => {
  cookies.delete("session", { path: "/" });
  return json({ message: "Sesión cerrada correctamente" });
};

export { POST };
//# sourceMappingURL=_server.ts-DVqf-cpw.js.map
