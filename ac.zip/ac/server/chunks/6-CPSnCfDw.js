const index = 6;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-DFlQhojL.js')).default;
const imports = ["_app/immutable/nodes/6.9K-dMGUF.js","_app/immutable/chunks/disclose-version.CBbrbG3j.js","_app/immutable/chunks/runtime.CYoiLdmP.js","_app/immutable/chunks/render.B8Gi3m-6.js","_app/immutable/chunks/events.D_Kh9_Cj.js","_app/immutable/chunks/if.DM2tvzsw.js","_app/immutable/chunks/each.CwO15nsP.js","_app/immutable/chunks/attributes.ERSpOZb7.js","_app/immutable/chunks/input.BQSx1zKk.js","_app/immutable/chunks/lifecycle.BoDPO5kt.js","_app/immutable/chunks/index-client.CX9LO-Jo.js"];
const stylesheets = ["_app/immutable/assets/6.DpREgJ3L.css"];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=6-CPSnCfDw.js.map
