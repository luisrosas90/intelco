const index = 5;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-P6pckH3N.js')).default;
const imports = ["_app/immutable/nodes/5.CZsNAQo6.js","_app/immutable/chunks/5.CuZLsJZV.js","_app/immutable/chunks/disclose-version.CBbrbG3j.js","_app/immutable/chunks/runtime.CYoiLdmP.js","_app/immutable/chunks/render.B8Gi3m-6.js","_app/immutable/chunks/events.D_Kh9_Cj.js","_app/immutable/chunks/if.DM2tvzsw.js","_app/immutable/chunks/attributes.ERSpOZb7.js","_app/immutable/chunks/lifecycle.BoDPO5kt.js","_app/immutable/chunks/index-client.CX9LO-Jo.js","_app/immutable/chunks/props.CW_e8doA.js","_app/immutable/chunks/proxy.B8xqnh-n.js","_app/immutable/chunks/input.BQSx1zKk.js","_app/immutable/chunks/event-modifiers.Dejc541Y.js","_app/immutable/chunks/each.CwO15nsP.js","_app/immutable/chunks/select.CFrhdko_.js","_app/immutable/chunks/preload-helper.B5Jg7y3B.js"];
const stylesheets = ["_app/immutable/assets/5.DE-Lona4.css"];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=5-Cu7WaHqa.js.map
