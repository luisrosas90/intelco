import { p as pool } from './db-DmdxKCrm.js';
import { j as json } from './index-DHSpIlkf.js';
import 'mysql2/promise';

const GET = async ({ url }) => {
  const cajero_id = url.searchParams.get("cajero_id");
  if (!cajero_id) {
    return json({ success: false, message: "Cajero ID es requerido." }, { status: 400 });
  }
  try {
    const [historial] = await pool.query(
      "SELECT tipo_operacion, monto, motivo, fecha FROM historial_operaciones WHERE cajero_id = ? ORDER BY fecha DESC",
      [cajero_id]
    );
    return json({ success: true, historial });
  } catch (error) {
    console.error("Error fetching historial:", error);
    return json({ success: false, message: "Error fetching historial." }, { status: 500 });
  }
};

export { GET };
//# sourceMappingURL=_server.ts-2CPCsjFk.js.map
