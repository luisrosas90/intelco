import { l as attr, m as stringify, f as slot, o as bind_props, e as pop, p as push } from './index2-aFjvJk03.js';
import './client-BUusD8wq.js';
import { d as default_slot } from './misc-b9uXgm3X.js';
import './exports-BGi7-Rnc.js';

function _layout($$payload, $$props) {
  push();
  let data = $$props["data"];
  $$payload.out += `<nav class="bg-blue-600 p-4 shadow-md flex justify-between items-center svelte-1sa6c1k"><div class="space-x-4"><a${attr("href", `/${stringify(data.user)}/dashboard`)} class="bg-white text-blue-600 px-4 py-2 rounded hover:bg-gray-200 transition-all svelte-1sa6c1k">Inicio</a></div> <div class="space-x-4">`;
  if (data.user) {
    $$payload.out += "<!--[-->";
    $$payload.out += `<button class="bg-red-600 text-white px-4 py-2 rounded hover:bg-red-500 transition-all svelte-1sa6c1k">Cerrar Sesión</button>`;
  } else {
    $$payload.out += "<!--[!-->";
    $$payload.out += `<a href="/login" class="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-500 transition-all svelte-1sa6c1k">Iniciar Sesión</a>`;
  }
  $$payload.out += `<!--]--></div></nav> <div class="mt-8 p-4"><!---->`;
  slot($$payload, default_slot($$props), {});
  $$payload.out += `<!----></div>`;
  bind_props($$props, { data });
  pop();
}

export { _layout as default };
//# sourceMappingURL=_layout.svelte-Kzcm4X-Q.js.map
