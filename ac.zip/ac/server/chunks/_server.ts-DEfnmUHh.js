import { p as pool } from './db-DmdxKCrm.js';
import { j as json } from './index-DHSpIlkf.js';
import fs from 'fs';
import path from 'path';
import 'mysql2/promise';

const POST = async ({ request }) => {
  try {
    const formData = await request.formData();
    const clienteId = formData.get("cliente_id");
    const monto = formData.get("monto");
    const metodoPago = formData.get("metodo_pago");
    const referenciaPago = formData.get("referencia_pago");
    const pdf = formData.get("pdf");
    if (!clienteId || !monto || !metodoPago || !referenciaPago || !pdf) {
      return json({ message: "Faltan datos obligatorios" }, { status: 400 });
    }
    const [result] = await pool.execute(
      `INSERT INTO recibos (cliente_id, monto, metodo_pago, referencia_pago, created_at)
       VALUES (?, ?, ?, ?, NOW())`,
      [clienteId, monto, metodoPago, referenciaPago]
    );
    const insertId = result.insertId;
    const filePath = path.resolve(`./static/recibos/recibo_${insertId}.pdf`);
    const buffer = Buffer.from(await pdf.arrayBuffer());
    fs.writeFileSync(filePath, buffer);
    return json({ message: "Recibo registrado correctamente", reciboId: insertId }, { status: 201 });
  } catch (error) {
    console.error("Error al insertar el recibo:", error);
    return json({ message: "Error al insertar el recibo" }, { status: 500 });
  }
};

export { POST };
//# sourceMappingURL=_server.ts-DEfnmUHh.js.map
