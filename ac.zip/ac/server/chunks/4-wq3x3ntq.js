const index = 4;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-BOzEz9MO.js')).default;
const imports = ["_app/immutable/nodes/4.BzFhhH3M.js","_app/immutable/chunks/disclose-version.CBbrbG3j.js","_app/immutable/chunks/runtime.CYoiLdmP.js","_app/immutable/chunks/render.B8Gi3m-6.js","_app/immutable/chunks/events.D_Kh9_Cj.js","_app/immutable/chunks/if.DM2tvzsw.js","_app/immutable/chunks/attributes.ERSpOZb7.js","_app/immutable/chunks/input.BQSx1zKk.js","_app/immutable/chunks/select.CFrhdko_.js","_app/immutable/chunks/proxy.B8xqnh-n.js","_app/immutable/chunks/event-modifiers.Dejc541Y.js","_app/immutable/chunks/lifecycle.BoDPO5kt.js","_app/immutable/chunks/index-client.CX9LO-Jo.js"];
const stylesheets = ["_app/immutable/assets/4.B_SY1GJM.css","_app/immutable/assets/app.CLF7lq6g.css"];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=4-wq3x3ntq.js.map
