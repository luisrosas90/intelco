import { f as fail } from './index-DHSpIlkf.js';

const actions = {
  default: async ({ request }) => {
    const formData = await request.formData();
    const monto = formData.get("monto");
    if (!monto) {
      return fail(400, { error: "El monto es requerido" });
    }
    return { success: true };
  }
};

var _page_server_ts = /*#__PURE__*/Object.freeze({
  __proto__: null,
  actions: actions
});

const index = 7;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-DqVUlBYC.js')).default;
const server_id = "src/routes/[cajero]/pagos/+page.server.ts";
const imports = ["_app/immutable/nodes/7.mP0QpOZp.js","_app/immutable/chunks/disclose-version.CBbrbG3j.js","_app/immutable/chunks/runtime.CYoiLdmP.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, _page_server_ts as server, server_id, stylesheets };
//# sourceMappingURL=7-C2oKedM1.js.map
