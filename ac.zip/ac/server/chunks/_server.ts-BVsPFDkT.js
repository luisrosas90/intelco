import { j as json } from './index-DHSpIlkf.js';
import bcrypt from 'bcryptjs';
import { p as pool } from './db-DmdxKCrm.js';
import 'mysql2/promise';

const POST = async ({ request }) => {
  const { email, password } = await request.json();
  if (!email || !password) {
    return json(
      { success: false, message: "Todos los campos son obligatorios." },
      { status: 400 }
    );
  }
  try {
    const [rows] = await pool.execute("SELECT * FROM admin WHERE email = ?", [email]);
    if (rows.length === 0) {
      return json(
        { success: false, message: "Administrador no encontrado." },
        { status: 404 }
      );
    }
    const admin = rows[0];
    const validPassword = await bcrypt.compare(password, admin.password);
    if (!validPassword) {
      return json(
        { success: false, message: "Contraseña incorrecta." },
        { status: 403 }
      );
    }
    return json(
      { success: true, message: "Login exitoso", admin: { id: admin.id, email: admin.email } },
      { status: 200 }
    );
  } catch (error) {
    console.error("Error en el login:", error);
    return json(
      { success: false, message: "Error en el servidor." },
      { status: 500 }
    );
  }
};

export { POST };
//# sourceMappingURL=_server.ts-BVsPFDkT.js.map
