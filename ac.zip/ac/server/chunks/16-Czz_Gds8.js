const index = 16;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-BF5oqf5c.js')).default;
const imports = ["_app/immutable/nodes/16.B5ZY8olW.js","_app/immutable/chunks/disclose-version.CBbrbG3j.js","_app/immutable/chunks/runtime.CYoiLdmP.js","_app/immutable/chunks/render.B8Gi3m-6.js","_app/immutable/chunks/events.D_Kh9_Cj.js","_app/immutable/chunks/if.DM2tvzsw.js","_app/immutable/chunks/each.CwO15nsP.js","_app/immutable/chunks/lifecycle.BoDPO5kt.js","_app/immutable/chunks/index-client.CX9LO-Jo.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=16-Czz_Gds8.js.map
