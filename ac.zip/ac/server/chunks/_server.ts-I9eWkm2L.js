import { p as pool } from './db-DmdxKCrm.js';
import { j as json } from './index-DHSpIlkf.js';
import 'mysql2/promise';

const POST = async ({ request }) => {
  const { idPago } = await request.json();
  try {
    await pool.query(`
      UPDATE reportes_pagos
      SET estado = 'procesado'
      WHERE id = ?
    `, [idPago]);
    return json({ success: true, message: "Pago validado exitosamente." });
  } catch (error) {
    console.error("Error al validar el pago:", error);
    return json({ success: false, message: "Error al validar el pago." });
  }
};

export { POST };
//# sourceMappingURL=_server.ts-I9eWkm2L.js.map
