import { q as ensure_array_like, h as escape_html, e as pop, p as push } from './index2-aFjvJk03.js';

function _page($$payload, $$props) {
  push();
  let reportesPendientes = [];
  const each_array = ensure_array_like(reportesPendientes);
  $$payload.out += `<section><h1 class="text-2xl font-bold">Reportes Pendientes de Clientes</h1> <ul><!--[-->`;
  for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
    const reporte = each_array[$$index];
    $$payload.out += `<li class="reporte-item svelte-1706u9x"><p><strong>Cliente:</strong> ${escape_html(reporte.cliente_nombre)}</p> <p><strong>Monto:</strong> ${escape_html(reporte.monto)} Bs</p> <p><strong>Referencia:</strong> ${escape_html(reporte.referencia_pago)}</p> <button class="button-validar svelte-1706u9x">Validar</button> <button class="button-rechazar svelte-1706u9x">Rechazar</button></li>`;
  }
  $$payload.out += `<!--]--></ul></section>`;
  pop();
}

export { _page as default };
//# sourceMappingURL=_page.svelte-CpK8IA7K.js.map
