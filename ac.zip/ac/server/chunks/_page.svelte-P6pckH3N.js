import { l as attr, e as pop, p as push, h as escape_html, o as bind_props, q as ensure_array_like } from './index2-aFjvJk03.js';
import 'jspdf';

function Header($$payload, $$props) {
  push();
  let usuario = $$props["usuario"];
  let changeSection = $$props["changeSection"];
  $$payload.out += `<header class="svelte-o90cku"><h1>Bienvenido, ${escape_html(usuario)}</h1> <nav class="svelte-o90cku"><button class="svelte-o90cku">Pagos</button> <button class="svelte-o90cku">Historial</button> <button class="svelte-o90cku">Recibos</button> <button class="svelte-o90cku">Reportes</button></nav></header>`;
  bind_props($$props, { usuario, changeSection });
  pop();
}
function Pagos($$payload, $$props) {
  push();
  let cedula = "";
  $$payload.out += `<section><h2 class="text-xl font-bold mb-4">Pagos</h2> <section class="w-full max-w-md px-5 py-6 mx-auto bg-white rounded-md shadow-md"><div class="flex flex-col items-center"><form id="searchForm" class="w-full"><label for="cedula" class="block text-lg font-medium text-gray-700 text-center mb-2">Cédula del Cliente</label> <input id="cedula"${attr("value", cedula)} required class="w-full py-3 pl-4 pr-4 text-gray-700 bg-white border border-gray-300 rounded-md focus:border-blue-400 focus:outline-none focus:ring focus:ring-blue-300"> <button type="submit" class="flex items-center justify-center w-full px-4 py-2 mt-4 font-medium tracking-wide text-white capitalize transition-colors duration-300 transform bg-blue-600 rounded-lg hover:bg-blue-500 focus:outline-none">Buscar Cliente</button></form></div></section> `;
  {
    $$payload.out += "<!--[!-->";
  }
  $$payload.out += `<!--]--> `;
  {
    $$payload.out += "<!--[!-->";
  }
  $$payload.out += `<!--]--> `;
  {
    $$payload.out += "<!--[!-->";
  }
  $$payload.out += `<!--]--></section>`;
  pop();
}
function Historial($$payload, $$props) {
  push();
  let recibos = [];
  $$payload.out += `<section><h2>Historial de Transacciones</h2> `;
  {
    $$payload.out += "<!--[!-->";
  }
  $$payload.out += `<!--]--> `;
  if (recibos.length > 0) {
    $$payload.out += "<!--[-->";
    const each_array = ensure_array_like(recibos);
    $$payload.out += `<ul class="svelte-qd5fmj"><!--[-->`;
    for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
      const recibo = each_array[$$index];
      $$payload.out += `<li class="svelte-qd5fmj">Fecha: ${escape_html(recibo.fecha)} - Monto: ${escape_html(recibo.monto)} Bs - Método: ${escape_html(recibo.metodo_pago)}</li>`;
    }
    $$payload.out += `<!--]--></ul>`;
  } else {
    $$payload.out += "<!--[!-->";
  }
  $$payload.out += `<!--]--></section>`;
  pop();
}
function Recibos($$payload, $$props) {
  push();
  let recibos = [];
  $$payload.out += `<section><h2 class="text-xl font-bold mb-4 svelte-192erux">Recibos</h2> `;
  {
    $$payload.out += "<!--[!-->";
  }
  $$payload.out += `<!--]--> `;
  if (recibos.length > 0) {
    $$payload.out += "<!--[-->";
    const each_array = ensure_array_like(recibos);
    $$payload.out += `<ul class="divide-y divide-gray-300 svelte-192erux"><!--[-->`;
    for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
      const recibo = each_array[$$index];
      $$payload.out += `<li class="py-2 svelte-192erux"><p><strong>ID Recibo:</strong> ${escape_html(reicbo.id)}</p> <p><strong>Cliente ID:</strong> ${escape_html(recibo.cliente_id)}</p> <p><strong>Método de Pago:</strong> ${escape_html(recibo.metodo_pago)}</p> <p><strong>Monto:</strong> ${escape_html(recibo.monto)} Bs</p> <p><strong>Referencia:</strong> ${escape_html(recibo.referencia_pago)}</p> <p><strong>Fecha:</strong> ${escape_html(new Date(recibo.created_at).toLocaleDateString())}</p></li>`;
    }
    $$payload.out += `<!--]--></ul>`;
  } else {
    $$payload.out += "<!--[!-->";
    {
      $$payload.out += "<!--[-->";
      $$payload.out += `<p>No hay recibos disponibles en este momento.</p>`;
    }
    $$payload.out += `<!--]-->`;
  }
  $$payload.out += `<!--]--></section>`;
  pop();
}
function Reportes($$payload, $$props) {
  push();
  let reportes = [];
  $$payload.out += `<section><h2 class="text-xl font-bold mb-4 svelte-192erux">Reportes</h2> `;
  {
    $$payload.out += "<!--[!-->";
  }
  $$payload.out += `<!--]--> `;
  if (reportes.length > 0) {
    $$payload.out += "<!--[-->";
    const each_array = ensure_array_like(reportes);
    $$payload.out += `<ul class="divide-y divide-gray-300 svelte-192erux"><!--[-->`;
    for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
      const reporte = each_array[$$index];
      $$payload.out += `<li class="py-2 svelte-192erux"><p><strong>Fecha:</strong> ${escape_html(new Date(reporte.fecha).toLocaleString())}</p> <p><strong>Descripción:</strong> ${escape_html(reporte.descripcion)}</p> <p><strong>Monto:</strong> ${escape_html(typeof reporte.monto === "number" ? reporte.monto.toFixed(2) : "Monto no disponible")} Bs</p></li>`;
    }
    $$payload.out += `<!--]--></ul>`;
  } else {
    $$payload.out += "<!--[!-->";
    {
      $$payload.out += "<!--[-->";
      $$payload.out += `<p>No hay reportes disponibles en este momento.</p>`;
    }
    $$payload.out += `<!--]-->`;
  }
  $$payload.out += `<!--]--></section>`;
  pop();
}
function Dashboard($$payload, $$props) {
  push();
  let activeSection = "historial";
  let usuario = "Usuario de ejemplo";
  let loading = false;
  const changeSection = (section) => {
    activeSection = section;
  };
  Header($$payload, { usuario, changeSection });
  $$payload.out += `<!----> <section class="svelte-uubsgp">`;
  if (activeSection === "pagos") {
    $$payload.out += "<!--[-->";
    Pagos($$payload);
  } else {
    $$payload.out += "<!--[!-->";
    if (activeSection === "historial") {
      $$payload.out += "<!--[-->";
      Historial($$payload);
    } else {
      $$payload.out += "<!--[!-->";
      if (activeSection === "recibos") {
        $$payload.out += "<!--[-->";
        Recibos($$payload);
      } else {
        $$payload.out += "<!--[!-->";
        if (activeSection === "reportes") {
          $$payload.out += "<!--[-->";
          Reportes($$payload);
        } else {
          $$payload.out += "<!--[!-->";
        }
        $$payload.out += `<!--]-->`;
      }
      $$payload.out += `<!--]-->`;
    }
    $$payload.out += `<!--]-->`;
  }
  $$payload.out += `<!--]--></section> <section class="svelte-uubsgp"><h2 class="text-xl font-bold mb-4">Dashboard - Generar Reporte Diario</h2> `;
  {
    $$payload.out += "<!--[!-->";
  }
  $$payload.out += `<!--]--> `;
  {
    $$payload.out += "<!--[!-->";
  }
  $$payload.out += `<!--]--> <button${attr("disabled", loading, true)} class="btn btn-primary svelte-uubsgp">`;
  {
    $$payload.out += "<!--[!-->";
    $$payload.out += `Generar Reporte Diario`;
  }
  $$payload.out += `<!--]--></button> `;
  {
    $$payload.out += "<!--[!-->";
  }
  $$payload.out += `<!--]--></section>`;
  pop();
}
function _page($$payload) {
  Dashboard($$payload);
}

export { _page as default };
//# sourceMappingURL=_page.svelte-P6pckH3N.js.map
