import { f as slot } from './index2-aFjvJk03.js';
import { d as default_slot } from './misc-b9uXgm3X.js';

function Layout($$payload, $$props) {
  $$payload.out += `<!---->`;
  slot($$payload, default_slot($$props), {});
  $$payload.out += `<!---->`;
}

export { Layout as default };
//# sourceMappingURL=layout.svelte-wZkFU84-.js.map
