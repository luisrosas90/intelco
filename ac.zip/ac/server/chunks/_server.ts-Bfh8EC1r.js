import { j as json } from './index-DHSpIlkf.js';
import { p as pool } from './db-DmdxKCrm.js';
import fetch from 'node-fetch';
import dotenv from 'dotenv';
import 'mysql2/promise';

dotenv.config();
async function sendWhatsAppMessage(data) {
  try {
    const secret = process.env.WABASMS_API_SECRET;
    const accountId = process.env.WABASMS_ACCOUNT_ID;
    const adminPhone = process.env.ADMIN_PHONE;
    if (!secret || !accountId || !adminPhone) {
      throw new Error("Faltan variables de entorno necesarias.");
    }
    const whatsappPayload = {
      secret,
      account: accountId,
      recipient: data.recipient,
      type: "text",
      message: data.message,
      priority: 2
    };
    const response = await fetch("https://wabasms.com/api/send/whatsapp", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(whatsappPayload)
    });
    return response;
  } catch (error) {
    console.error("Error al enviar el mensaje de WhatsApp:", error);
    throw error;
  }
}
const POST = async ({ request }) => {
  try {
    const { clienteId, nombreCliente, montoEnUsd, facturaId, selectedMethod, referenceNumber, banco, telefono } = await request.json();
    if (!clienteId || !montoEnUsd || !facturaId || !referenceNumber || !banco || !telefono) {
      return json({ message: "Faltan datos obligatorios." }, { status: 400 });
    }
    const estado = "pendiente de validación";
    const [result] = await pool.execute(
      `
            INSERT INTO reportes_pagos (cliente_id, metodo_pago, monto, factura_id, estado, referencia_pago, moneda, telefono, banco)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            `,
      [clienteId, selectedMethod, montoEnUsd, facturaId, estado, referenceNumber, "USD", telefono, banco]
    );
    if (result.affectedRows === 0) {
      return json({ message: "No se pudo registrar el pago en la base de datos." }, { status: 500 });
    }
    const adminPhoneNumber = process.env.ADMIN_PHONE;
    if (!adminPhoneNumber) {
      return json({ message: "Número de teléfono del administrador no está configurado." }, { status: 500 });
    }
    const reportUrl = `https://reporte.corpintelco.com/admin/reportes`;
    const whatsappMessage = `Nuevo pago reportado:
        - Cliente: ${nombreCliente}
        - Monto: ${montoEnUsd} USD
        - Banco: ${banco}
        - Referencia: ${referenceNumber}
        - Teléfono: ${telefono}
        
        Valida el reporte aquí: ${reportUrl}`;
    const whatsappResponse = await sendWhatsAppMessage({
      recipient: adminPhoneNumber,
      message: whatsappMessage
    });
    if (!whatsappResponse.ok) {
      const errorDetails = await whatsappResponse.json();
      console.error("Error al enviar el mensaje de WhatsApp:", errorDetails);
      return json({ message: "Error al enviar la notificación de WhatsApp, pero el pago fue registrado." }, { status: 500 });
    }
    return json({ message: "Pago registrado y notificación de WhatsApp enviada correctamente." }, { status: 200 });
  } catch (error) {
    console.error("Error al procesar el pago:", error);
    return json({ message: "Error al procesar el pago." }, { status: 500 });
  }
};

export { POST };
//# sourceMappingURL=_server.ts-Bfh8EC1r.js.map
