import mysql from 'mysql2/promise';

const pool = mysql.createPool({
  host: "localhost",
  user: "reporte",
  password: "Lam1414*$",
  database: "reporte",
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

export { pool as p };
//# sourceMappingURL=db-DmdxKCrm.js.map
