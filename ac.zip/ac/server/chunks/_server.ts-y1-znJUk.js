import { r as redirect } from './index-DHSpIlkf.js';

const POST = async ({ cookies }) => {
  cookies.delete("session", { path: "/" });
  throw redirect(303, "/admin/login");
};

export { POST };
//# sourceMappingURL=_server.ts-y1-znJUk.js.map
