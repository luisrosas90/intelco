import { j as json } from './index-DHSpIlkf.js';
import { p as pool } from './db-DmdxKCrm.js';
import 'mysql2/promise';

const POST = async ({ request }) => {
  try {
    const { cajero_id, monto } = await request.json();
    const [result] = await pool.execute(
      `INSERT INTO caja (cajero_id, tipo, monto) VALUES (?, 'cierre', ?)`,
      [cajero_id, monto]
    );
    return json({ mensaje: "Cierre de caja registrado exitosamente.", result });
  } catch (error) {
    console.error("Error al registrar el cierre de caja:", error);
    return json({ mensaje: "Error al registrar el cierre de caja." }, { status: 500 });
  }
};

export { POST };
//# sourceMappingURL=_server.ts-CtTKxaoT.js.map
