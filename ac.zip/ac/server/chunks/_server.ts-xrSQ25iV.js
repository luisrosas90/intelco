import { p as pool } from './db-DmdxKCrm.js';
import { j as json } from './index-DHSpIlkf.js';
import 'mysql2/promise';

const GET = async () => {
  try {
    const [rows] = await pool.query(`
      SELECT id, cajero_id, tipo, monto, fecha
      FROM caja
    `);
    return json({ success: true, reportes: rows });
  } catch (error) {
    console.error("Error fetching cashier reports:", error);
    return json({ success: false, message: "Error al obtener reportes de cajeros" }, { status: 500 });
  }
};

export { GET };
//# sourceMappingURL=_server.ts-xrSQ25iV.js.map
