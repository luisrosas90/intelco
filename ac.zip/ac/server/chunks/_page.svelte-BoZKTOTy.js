import { q as ensure_array_like, h as escape_html, e as pop, p as push } from './index2-aFjvJk03.js';

function _page($$payload, $$props) {
  push();
  let reportesCajeros = [];
  const each_array = ensure_array_like(reportesCajeros);
  $$payload.out += `<section><h1 class="text-3xl font-bold mb-6">Reportes de Cajeros</h1> <ul><!--[-->`;
  for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
    const reporte = each_array[$$index];
    $$payload.out += `<li class="reporte-item svelte-1dkwa4d"><p><strong>Cajero:</strong> ${escape_html(reporte.cajero_nombre)}</p> <p><strong>Tipo:</strong> ${escape_html(reporte.tipo)}</p> <p><strong>Fecha:</strong> ${escape_html(reporte.fecha)}</p></li>`;
  }
  $$payload.out += `<!--]--></ul></section>`;
  pop();
}

export { _page as default };
//# sourceMappingURL=_page.svelte-BoZKTOTy.js.map
