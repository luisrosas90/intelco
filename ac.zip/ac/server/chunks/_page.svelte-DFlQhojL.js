import { l as attr, q as ensure_array_like, h as escape_html, e as pop, p as push } from './index2-aFjvJk03.js';

function _page($$payload, $$props) {
  push();
  let historial = [];
  let filterByClientId = "";
  let filterByDate = "";
  $$payload.out += `<section><h1>Historial de Transacciones</h1> `;
  {
    $$payload.out += "<!--[!-->";
  }
  $$payload.out += `<!--]--> `;
  {
    $$payload.out += "<!--[!-->";
  }
  $$payload.out += `<!--]--> <div class="filter svelte-1abl5mi"><label for="clientIdFilter">Filtrar por Cliente ID:</label> <input type="text" id="clientIdFilter"${attr("value", filterByClientId)} placeholder="Ingrese Cliente ID" class="w-full py-2 px-4 border rounded-md"></div> <div class="filter svelte-1abl5mi"><label for="dateFilter">Filtrar por Fecha:</label> <input type="date" id="dateFilter"${attr("value", filterByDate)} class="w-full py-2 px-4 border rounded-md"></div> `;
  if (historial.length > 0) {
    $$payload.out += "<!--[-->";
    const each_array = ensure_array_like(historial);
    $$payload.out += `<ul class="svelte-1abl5mi"><!--[-->`;
    for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
      const transaccion = each_array[$$index];
      $$payload.out += `<li class="mb-4 p-4 bg-gray-100 border border-gray-300 rounded svelte-1abl5mi"><p><strong>Cliente ID:</strong> ${escape_html(transaccion.cliente_id)}</p> <p><strong>Monto:</strong> ${escape_html(transaccion.monto)} USD</p> <p><strong>Método de Pago:</strong> ${escape_html(transaccion.metodo_pago)}</p> <p><strong>Fecha:</strong> ${escape_html(new Date(transaccion.fecha).toLocaleDateString())}</p> <p><strong>Referencia de Pago:</strong> ${escape_html(transaccion.referencia_pago)}</p> <p><strong>Banco Emisor:</strong> ${escape_html(transaccion.banco)}</p> <p><strong>ID Factura:</strong> ${escape_html(transaccion.factura_id)}</p></li>`;
    }
    $$payload.out += `<!--]--></ul>`;
  } else {
    $$payload.out += "<!--[!-->";
    $$payload.out += `<p>No hay transacciones en el historial.</p>`;
  }
  $$payload.out += `<!--]--></section>`;
  pop();
}

export { _page as default };
//# sourceMappingURL=_page.svelte-DFlQhojL.js.map
