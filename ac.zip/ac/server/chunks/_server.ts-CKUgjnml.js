import { p as pool } from './db-DmdxKCrm.js';
import { j as json } from './index-DHSpIlkf.js';
import 'mysql2/promise';

const GET = async () => {
  try {
    const [rows] = await pool.query(`
      SELECT id, cliente_id, monto, referencia_pago, estado, fecha_reporte
      FROM reportes_pendientes
      WHERE estado = 'pendiente'
    `);
    return json({ success: true, reportes: rows });
  } catch (error) {
    console.error("Error fetching pending reports:", error);
    return json({ success: false, message: "Error al obtener reportes" }, { status: 500 });
  }
};

export { GET };
//# sourceMappingURL=_server.ts-CKUgjnml.js.map
