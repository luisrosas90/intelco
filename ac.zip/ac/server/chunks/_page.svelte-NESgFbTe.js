import { q as ensure_array_like, h as escape_html, e as pop, p as push } from './index2-aFjvJk03.js';

function _page($$payload, $$props) {
  push();
  let reportesPendientes = [];
  let historialRecibos = [];
  $$payload.out += `<section><h1>Reportes Pendientes de Validación</h1> `;
  {
    $$payload.out += "<!--[!-->";
  }
  $$payload.out += `<!--]--> `;
  if (reportesPendientes.length > 0) {
    $$payload.out += "<!--[-->";
    const each_array = ensure_array_like(reportesPendientes);
    $$payload.out += `<ul class="svelte-1ucxl61"><!--[-->`;
    for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
      const reporte = each_array[$$index];
      $$payload.out += `<li class="mb-4 p-4 bg-gray-100 border border-gray-300 rounded svelte-1ucxl61"><p><strong>Cliente ID:</strong> ${escape_html(reporte.cliente_id)}</p> <p><strong>Monto:</strong> ${escape_html(reporte.monto)} USD</p> <p><strong>Número de Teléfono:</strong> ${escape_html(reporte.telefono)}</p> <p><strong>Referencia de Pago:</strong> ${escape_html(reporte.referencia_pago)}</p> <p><strong>Banco Emisor:</strong> ${escape_html(reporte.banco)}</p> <p><strong>ID Factura:</strong> ${escape_html(reporte.factura_id)}</p> <button class="bg-blue-500 text-white px-4 py-2 rounded mt-2 svelte-1ucxl61">Validar Pago</button></li>`;
    }
    $$payload.out += `<!--]--></ul>`;
  } else {
    $$payload.out += "<!--[!-->";
    $$payload.out += `<p>No hay reportes pendientes de validación.</p>`;
  }
  $$payload.out += `<!--]--></section> <section><h1>Historial de Recibos</h1> `;
  if (historialRecibos.length > 0) {
    $$payload.out += "<!--[-->";
    const each_array_1 = ensure_array_like(historialRecibos);
    $$payload.out += `<ul class="svelte-1ucxl61"><!--[-->`;
    for (let $$index_1 = 0, $$length = each_array_1.length; $$index_1 < $$length; $$index_1++) {
      const recibo = each_array_1[$$index_1];
      $$payload.out += `<li class="mb-4 p-4 bg-gray-100 border border-gray-300 rounded svelte-1ucxl61"><p><strong>Cliente ID:</strong> ${escape_html(recibo.cliente_id)}</p> <p><strong>Monto:</strong> ${escape_html(recibo.monto)} USD</p> <p><strong>Método de Pago:</strong> ${escape_html(recibo.metodo_pago)}</p> <p><strong>Fecha:</strong> ${escape_html(new Date(recibo.fecha).toLocaleDateString())}</p></li>`;
    }
    $$payload.out += `<!--]--></ul>`;
  } else {
    $$payload.out += "<!--[!-->";
    $$payload.out += `<p>No hay recibos en el historial.</p>`;
  }
  $$payload.out += `<!--]--></section> <section><button class="bg-green-500 text-white px-4 py-2 rounded svelte-1ucxl61">Imprimir todos los recibos del día</button></section>`;
  pop();
}

export { _page as default };
//# sourceMappingURL=_page.svelte-NESgFbTe.js.map
