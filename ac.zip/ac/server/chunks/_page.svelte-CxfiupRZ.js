import { l as attr, e as pop, p as push } from './index2-aFjvJk03.js';

function _page($$payload, $$props) {
  push();
  let cedula = "";
  $$payload.out += `<section class="container mx-auto p-4"><form id="searchForm" class="space-y-4"><label for="cedula" class="block text-gray-700">Cédula del Cliente</label> <input id="cedula"${attr("value", cedula)} required class="w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500"> <button type="submit" class="w-full bg-[#1e8ddf] text-white py-2 px-4 rounded-md shadow-md hover:bg-[#1b76d2] focus:outline-none focus:ring-2 focus:ring-blue-500">Buscar Cliente</button></form></section> `;
  {
    $$payload.out += "<!--[!-->";
  }
  $$payload.out += `<!--]--> `;
  {
    $$payload.out += "<!--[!-->";
  }
  $$payload.out += `<!--]-->`;
  pop();
}

export { _page as default };
//# sourceMappingURL=_page.svelte-CxfiupRZ.js.map
