import { j as json } from './index-DHSpIlkf.js';
import { p as pool } from './db-DmdxKCrm.js';
import 'mysql2/promise';

const GET = async () => {
  try {
    const [rows] = await pool.execute(`
      SELECT id, cliente_id, metodo_pago, monto, referencia_pago, created_at
      FROM recibos
      WHERE DATE(created_at) = CURDATE()
    `);
    if (rows.length > 0) {
      return json({ success: true, recibos: rows });
    } else {
      return json({ success: true, recibos: [], message: "No hay recibos generados hoy." });
    }
  } catch (error) {
    console.error("Error al obtener los recibos:", error);
    return json({ success: false, message: "Error al obtener los recibos." }, { status: 500 });
  }
};

export { GET };
//# sourceMappingURL=_server.ts-F0wwNPO_.js.map
