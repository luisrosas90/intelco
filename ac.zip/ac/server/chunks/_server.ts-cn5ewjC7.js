import { p as pool } from './db-DmdxKCrm.js';
import { j as json } from './index-DHSpIlkf.js';
import 'mysql2/promise';

const POST = async ({ request }) => {
  try {
    const { clienteId, monto, metodo_pago, referencia_pago, fecha } = await request.json();
    if (!clienteId || !monto || !metodo_pago || !referencia_pago || !fecha) {
      return json({ message: "Faltan datos obligatorios" }, { status: 400 });
    }
    const [result] = await pool.execute(
      `INSERT INTO reportes (cliente_id, monto, metodo_pago, referencia_pago, fecha)
       VALUES (?, ?, ?, ?, ?)`,
      [clienteId, monto, metodo_pago, referencia_pago, fecha]
    );
    if (result.affectedRows === 1) {
      return json({ message: "Reporte insertado correctamente", reportId: result.insertId }, { status: 201 });
    } else {
      return json({ message: "Error al insertar el reporte" }, { status: 500 });
    }
  } catch (error) {
    console.error("Error al insertar el reporte:", error);
    return json({ message: "Error al insertar el reporte" }, { status: 500 });
  }
};

export { POST };
//# sourceMappingURL=_server.ts-cn5ewjC7.js.map
