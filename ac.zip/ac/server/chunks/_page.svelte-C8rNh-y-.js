import { l as attr } from './index2-aFjvJk03.js';

/* empty css                  */
function _page($$payload) {
  let usuario = "";
  let clave = "";
  $$payload.out += `<div class="flex h-screen bg-gray-100"><aside class="w-64 bg-white p-6 shadow-md"><div class="text-center mb-8"><h2 class="text-xl font-bold text-green-500"><img src="/logo.png" alt="Logo" class="w-50 h-35"></h2></div></aside> <main class="flex-1 flex items-center justify-center p-6"><section class="w-full max-w-md px-5 py-6 mx-auto bg-white rounded-md shadow-md"><h2 class="text-2xl font-semibold text-center text-gray-700 mb-4">Iniciar Sesión</h2> <form class="space-y-4"><div><label for="usuario" class="block text-lg font-medium text-gray-700 mb-2">Usuario</label> <input type="text" id="usuario"${attr("value", usuario)} required class="w-full py-3 px-4 text-gray-700 bg-white border border-gray-300 rounded-md focus:border-blue-400 focus:outline-none focus:ring focus:ring-blue-300"></div> <div><label for="clave" class="block text-lg font-medium text-gray-700 mb-2">Clave</label> <input type="password" id="clave"${attr("value", clave)} required class="w-full py-3 px-4 text-gray-700 bg-white border border-gray-300 rounded-md focus:border-blue-400 focus:outline-none focus:ring focus:ring-blue-300"></div> <button type="submit" class="w-full py-3 px-4 text-white bg-blue-600 rounded-md hover:bg-blue-500 focus:outline-none">Iniciar Sesión</button> `;
  {
    $$payload.out += "<!--[!-->";
  }
  $$payload.out += `<!--]--></form></section></main></div>`;
}

export { _page as default };
//# sourceMappingURL=_page.svelte-C8rNh-y-.js.map
