import{a as t}from"../chunks/entry.DE6h7fMi.js";export{t as start};
