import{a as e}from"../chunks/5.CuZLsJZV.js";export{e as component};
