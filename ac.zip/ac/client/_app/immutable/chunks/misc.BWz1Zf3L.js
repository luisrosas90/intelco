import{z as r,B as a}from"./runtime.CYoiLdmP.js";function l(t,e,n,f){r&&a(),e===void 0||e(t,n)}function d(t){var e=t.$$slots?.default;return e===!0?t.children:e}export{d,l as s};
