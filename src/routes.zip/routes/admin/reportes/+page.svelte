<script lang="ts">
    import { onMount } from 'svelte';
    let reportesPendientes = [];
  
    const fetchReportesPendientes = async () => {
      const response = await fetch('/api/admin/reportes');
      const data = await response.json();
      
      if (response.ok && data.success) {
        reportesPendientes = data.reportes;
      }
    };
  
    const verificarReporte = async (reporteId: number) => {
      const response = await fetch('/api/admin/verificar-reporte', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ reporteId })
      });
  
      const data = await response.json();
      
      if (response.ok && data.success) {
        // Actualizar la lista de reportes
        reportesPendientes = reportesPendientes.filter(r => r.id !== reporteId);
        alert(data.message);
      } else {
        alert(data.message);
      }
    };
  
    onMount(fetchReportesPendientes);
  </script>
  
  <section>
    <h1>Reportes Pendientes</h1>
  
    {#if reportesPendientes.length > 0}
      <ul>
        {#each reportesPendientes as reporte}
          <li>
            <p><strong>Cliente ID:</strong> {reporte.cliente_id}</p>
            <p><strong>Monto:</strong> {reporte.monto} Bs</p>
            <p><strong>Referencia de Pago:</strong> {reporte.referencia_pago}</p>
            <button on:click={() => verificarReporte(reporte.id)}>Verificar</button>
          </li>
        {/each}
      </ul>
    {:else}
      <p>No hay reportes pendientes.</p>
    {/if}
  </section>
  
  <style>
    ul {
      list-style: none;
      padding: 0;
    }
    li {
      margin-bottom: 1rem;
      padding: 1rem;
      background-color: #f9f9f9;
      border: 1px solid #ddd;
    }
    button {
      background-color: #4caf50;
      color: white;
      padding: 0.5rem 1rem;
      border: none;
      cursor: pointer;
    }
  </style>
  