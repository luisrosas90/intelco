<!-- /src/routes/admin/dashboard/+page.svelte -->
<script lang="ts">
    import { onMount } from 'svelte';
  
    let totalClientes = 0;
    let totalReportesPendientes = 0;
    let totalCajeros = 0;
  
    const fetchDashboardData = async () => {
      const response = await fetch('/api/admin/dashboard');
      const data = await response.json();
      
      if (response.ok && data.success) {
        totalClientes = data.totalClientes;
        totalReportesPendientes = data.totalReportesPendientes;
        totalCajeros = data.totalCajeros;
      }
    };
  
    onMount(fetchDashboardData);

    const logout = async () => {
    const response = await fetch('/api/admin/logout', { method: 'POST' });

    if (response.ok) {
      // Redirigir al login después de cerrar sesión
      window.location.href = '/admin/login';
    } else {
      alert('Error al cerrar sesión');
    }
  };
  </script>
  
  <section class="dashboard">
    <h1 class="text-3xl font-bold mb-6">Panel de Administración</h1>
    <button on:click={logout} class="bg-red-600 text-white px-4 py-2 rounded hover:bg-red-500">
      Cerrar Sesión
    </button>
  
    <div class="stats-grid">
      <div class="stat-item">
        <h2>Total de Clientes</h2>
        <p>{totalClientes}</p>
      </div>
  
      <div class="stat-item">
        <h2>Reportes Pendientes</h2>
        <p>{totalReportesPendientes}</p>
      </div>
  
      <div class="stat-item">
        <h2>Total de Cajeros</h2>
        <p>{totalCajeros}</p>
      </div>
    </div>
  </section>
  
  <style>
    .dashboard {
      max-width: 1200px;
      margin: 0 auto;
      padding: 2rem;
    }
    .stats-grid {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 2rem;
    }
    .stat-item {
      background-color: white;
      padding: 1.5rem;
      border-radius: 10px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
      text-align: center;
    }
    .stat-item h2 {
      font-size: 1.5rem;
      margin-bottom: 1rem;
    }
  </style>
  