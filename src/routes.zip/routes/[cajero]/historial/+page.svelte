<script>
  let historial = [
    { fecha: '2024-09-01', monto: 150, metodo: 'Efectivo', cliente: 'Juan Perez' },
    { fecha: '2024-09-02', monto: 300, metodo: 'Transferencia', cliente: 'Maria Garcia' }
  ]; // Estos datos pueden ser cargados desde una API

  function buscarHistorial(cedula) {
    // Lógica para obtener el historial desde la API según la cédula del cliente
    // historial = await fetch(`/api/historial/${cedula}`).then(res => res.json());
  }
</script>

<section>
  <h2>Historial de Transacciones</h2>
  <input type="text" placeholder="Cédula" on:input={(e) => buscarHistorial(e.target.value)} />

  <ul>
    {#each historial as item}
      <li>{item.fecha}: {item.monto} VES - {item.metodo} - Cliente: {item.cliente}</li>
    {/each}
  </ul>
</section>
