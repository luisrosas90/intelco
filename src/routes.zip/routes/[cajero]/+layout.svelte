<script lang="ts">
  export let data; // Datos del cajero autenticado
</script>

<nav>
  <ul>
    <li><a href="/{data.cajero}/inicio">Inicio</a></li>
    <li><a href="/{data.cajero}/pagos">Pagos</a></li>
  </ul>
</nav>

<form method="POST" action="/logout">
  <button type="submit">Cerrar Sesión</button>
</form>

<slot />
