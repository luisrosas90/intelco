import { redirect } from '@sveltejs/kit';
import { getUserRoleFromSession } from '$lib/utils/session';

export const load = async ({ cookies }) => {
  const session = cookies.get('session');

  if (!session) {
    throw redirect(303, '/login'); // Redirige al login si no hay sesión
  }

  // Opcionalmente, podrías verificar el rol del usuario en la base de datos:
  const userRole = getUserRoleFromSession(session);
  
  if (userRole !== 'cajero') {
    throw redirect(303, '/login'); // Redirige si no es cajero
  }

  return {
    user: session // Devuelve la sesión al layout si todo está bien
  };
};
