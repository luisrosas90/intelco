import { json } from '@sveltejs/kit';

// Función auxiliar que no se exporta
const _helperFunction = (data: any) => {
    // Validación o manipulación de datos, si es necesario
    return data;
};

// Manejador para solicitudes GET
export const GET = async () => {
    try {
        const data = _helperFunction({ message: 'GET request received' });
        return json(data, { status: 200 });
    } catch (error) {
        console.error('Error handling GET request:', error);
        return json({ error: 'Error handling GET request' }, { status: 500 });
    }
};

// Manejador para solicitudes POST
export const POST = async ({ request }) => {
    try {
        // Leer datos del cuerpo de la solicitud
        const body = await request.json();

        // Validar que los datos esenciales están presentes
        const { recipient, message } = body;
        if (!recipient || !message) {
            return json({ error: 'Parámetros faltantes: recipient y message son obligatorios.' }, { status: 400 });
        }

        // Procesar datos utilizando la función auxiliar
        const processedData = _helperFunction(body);

        // Enviar los datos a la API de WhatsApp
        const whatsappResponse = await sendWhatsAppMessage(processedData);

        if (!whatsappResponse.ok) {
            const errorMessage = await whatsappResponse.json();
            return json({ error: 'Error al enviar el mensaje de WhatsApp', details: errorMessage }, { status: 500 });
        }

        return json({ success: true, message: 'Mensaje de WhatsApp enviado con éxito' }, { status: 200 });
    } catch (error: any) {
        console.error('Error handling POST request:', error);
        return json({ error: 'Error al procesar la solicitud', details: error.message }, { status: 500 });
    }
};

// Función para enviar un mensaje de WhatsApp a través de la API de WabaSMS
async function sendWhatsAppMessage(data: any) {
    try {
        // Datos necesarios para la API de WabaSMS
        const whatsappPayload = {
            secret: process.env.WABASMS_API_SECRET, // El secreto de la API desde el entorno
            account: process.env.WABASMS_ACCOUNT_ID, // ID de la cuenta desde el entorno
            recipient: data.recipient, // Número de teléfono del destinatario
            type: 'text', // Tipo de mensaje (puede ser 'text', 'media', o 'document')
            message: data.message, // Mensaje a enviar
            priority: 2 // Prioridad (1 = prioridad, 2 = normal)
        };

        // Realizar la petición POST a la API de WabaSMS
        const response = await fetch('https://wabasms.com/api/send/whatsapp', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(whatsappPayload),
        });

        return response;
    } catch (error) {
        console.error('Error sending WhatsApp message:', error);
        throw error;
    }
}
