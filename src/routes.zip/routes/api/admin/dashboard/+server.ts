// src/routes/api/admin/dashboard/+server.ts
import { json } from '@sveltejs/kit';
import { pool } from '$lib/db';

export const GET = async () => {
  try {
    // Consulta para obtener los reportes del dashboard
    const [rows] = await pool.execute(`
      SELECT r.id, r.cliente_id, c.nombre AS cliente_nombre, r.referencia_pago, r.monto, r.estado
      FROM reportes_pendientes r
      JOIN clientes c ON r.cliente_id = c.id
    `);

    return json({ success: true, reportes: rows });
  } catch (error) {
    console.error('Error al obtener los datos del dashboard:', error);
    return json({ success: false, message: 'Error al obtener los datos del dashboard' }, { status: 500 });
  }
};
