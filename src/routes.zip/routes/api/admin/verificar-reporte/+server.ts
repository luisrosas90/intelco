import { json } from '@sveltejs/kit';
import { pool } from '$lib/db';

export const POST = async ({ request }) => {
  const { reporteId } = await request.json();

  // Validar que se haya recibido el ID del reporte
  if (!reporteId) {
    return json({ success: false, message: 'El ID del reporte es obligatorio.' }, { status: 400 });
  }

  try {
    // Actualizar el estado del reporte a "verificado"
    const [result] = await pool.execute(
      `UPDATE reportes_pendientes SET estado = 'verificado' WHERE id = ?`,
      [reporteId]
    );

    // Verificar si se ha actualizado alguna fila
    const affectedRows = (result as any).affectedRows;

    if (!affectedRows) {
      return json({ success: false, message: 'No se encontró el reporte.' }, { status: 404 });
    }

    return json({ success: true, message: 'Reporte verificado exitosamente.' });
  } catch (error) {
    console.error('Error al verificar el reporte:', error);
    return json({ success: false, message: 'Error al verificar el reporte.' });
  }
};
