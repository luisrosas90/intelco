// src/routes/api/operaciones/historial/+server.ts
import type { RequestHandler } from '@sveltejs/kit';
import { json } from '@sveltejs/kit';
import { pool } from '$lib/db'; // Asegúrate de que esta ruta sea correcta

export const GET: RequestHandler = async ({ url }) => {
  try {
    const cliente_id = url.searchParams.get('cliente_id'); // Obtener el cliente_id de los parámetros de la URL

    let query = 'SELECT * FROM operaciones';
    const params: (string | number)[] = [];

    if (cliente_id) {
      query += ' WHERE cliente_id = ?';
      params.push(cliente_id);
    }

    const [result] = await pool.query(query, params);

    return json(result);
  } catch (error) {
    console.error('Error al obtener el historial de operaciones:', error);
    return json({ mensaje: 'Error al obtener el historial de operaciones.' }, { status: 500 });
  }
};
