import type { RequestHandler } from '@sveltejs/kit';
import { json } from '@sveltejs/kit';
import { cajerosConfig } from '$lib/config/cajeros';

export const POST: RequestHandler = async ({ request }) => {
  try {
    const { usuario, contraseña } = await request.json();

    // Verifica que el usuario y la contraseña coincidan con la configuración de cajeros
    const cajeroValido = Object.values(cajerosConfig).some(
      cajero => cajero.usuario === usuario && cajero.contraseña === contraseña
    );

    if (cajeroValido) {
      // Genera un token simple para autenticación (puedes usar JWT o cualquier otra estrategia)
      const authToken = Buffer.from(`${usuario}:${contraseña}`).toString('base64');

      return json({ success: true, authToken }, { status: 200 });
    } else {
      return json({ success: false, message: 'Usuario o contraseña incorrectos' }, { status: 403 });
    }
  } catch (error) {
    console.error('Error en la autenticación:', error);
    return json({ success: false, message: 'Error en el servidor' }, { status: 500 });
  }
};
