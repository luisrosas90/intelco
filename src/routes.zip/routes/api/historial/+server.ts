// // src/routes/api/historial/+server.ts
 import { json } from '@sveltejs/kit';

 interface Operacion {
    id: number;
    fecha: string;
    tipo: string;
    monto: number;
    descripcion?: string;
}
 const historialDB = new Map<string, Operacion[]>(); // Usa el tipo específico


 export async function GET({ url }) {
   const token = url.searchParams.get('token');
   if (!token) return json({ error: 'Token requerido' }, { status: 400 });

   const historial = historialDB.get(token) || [];
   return json(historial);
 }

 export async function POST({ request }) {
   const { token, transaccion } = await request.json();
   if (!token || !transaccion) return json({ error: 'Datos incompletos' }, { status: 400 });

   if (!historialDB.has(token)) historialDB.set(token, []);
   const historial = historialDB.get(token);
if (historial) {
  historial.push(transaccion);
}

   return json({ success: true });
 }
