import { json } from '@sveltejs/kit';
import { pool } from '$lib/db'; // Asegúrate de tener configurada la conexión a la base de datos

export const POST = async ({ request }) => {
  try {
    // Extraer los datos de la solicitud
    const { cliente_id, referencia_pago, monto } = await request.json();

    // Validación de los datos
    if (!cliente_id || !referencia_pago || !monto) {
      return json({ success: false, message: 'Todos los campos son obligatorios' }, { status: 400 });
    }

    // Insertar el reporte de pago en la tabla
    const [result] = await pool.execute(
      `INSERT INTO reportes_pendientes (cliente_id, referencia_pago, monto, estado) VALUES (?, ?, ?, 'pendiente')`,
      [cliente_id, referencia_pago, monto]
    );

    // Enviar respuesta de éxito
    return json({ success: true, reporteId: result.insertId });
  } catch (error) {
    console.error('Error al crear el reporte pendiente:', error);
    return json({ success: false, message: 'Error al crear el reporte' }, { status: 500 });
  }
};
