// /src/routes/api/reportes/+server.ts
import { json } from '@sveltejs/kit';
import { pool } from '$lib/db';

export const POST = async ({ request }) => {
    const { reporteId, accion } = await request.json(); // La acción puede ser 'verificar' o 'rechazar'

    if (!reporteId || !accion) {
        return json({ success: false, message: 'Todos los campos son obligatorios.' }, { status: 400 });
    }

    try {
        // Cambiar el estado del reporte según la acción
        const estado = accion === 'verificar' ? 'verificado' : 'rechazado';
        await pool.execute('UPDATE reportes_pendientes SET estado = ? WHERE id = ?', [estado, reporteId]);

        return json({ success: true, message: `Reporte ${accion === 'verificar' ? 'verificado' : 'rechazado'}` });
    } catch (error) {
        return json({ success: false, message: 'Error al actualizar el estado del reporte' });
    }
};
