<script lang="ts">
  import { goto } from '$app/navigation';
  import { cajerosConfig } from '$lib/config/cajeros'; // Configuración de cajeros
  
  let usuario = '';
  let clave = '';
  let error = '';

  const autenticar = () => {
    const cajero = Object.values(cajerosConfig).find(
      c => c.usuario === usuario && c.clave === clave
    );

    if (cajero) {
      // Guardar en sessionStorage
      sessionStorage.setItem('cajero', cajero.usuario);

      // Redirigir al dashboard del cajero
      goto(`/${cajero.usuario}/inicio`);
    } else {
      error = 'Usuario o clave incorrectos';
    }
  };
</script>

<section class="max-w-md mx-auto mt-10 bg-white p-6 rounded-md shadow-md">
  <h2 class="text-2xl font-semibold text-center mb-4">Login de Cajeros</h2>

  <form on:submit|preventDefault={autenticar}>
    <div class="mb-4">
      <label for="usuario" class="block text-gray-700 font-semibold">Usuario</label>
      <input id="usuario" bind:value={usuario} class="w-full px-4 py-2 border rounded-md" required />
    </div>

    <div class="mb-4">
      <label for="clave" class="block text-gray-700 font-semibold">Clave</label>
      <input id="clave" type="password" bind:value={clave} class="w-full px-4 py-2 border rounded-md" required />
    </div>

    {#if error}
      <p class="text-red-500">{error}</p>
    {/if}

    <button type="submit" class="w-full bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-500">
      Iniciar Sesión
    </button>
  </form>
</section>
