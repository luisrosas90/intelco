import { fail, redirect } from '@sveltejs/kit';
import { cajerosConfig } from '$lib/config/cajeros';
import type { Actions } from './$types';

export const actions: Actions = {
  default: async ({ request, cookies }) => {
    const formData = await request.formData();
    const usuario = formData.get('usuario') as string;
    const clave = formData.get('clave') as string;

    // Verificar credenciales
    const cajero = Object.values(cajerosConfig).find(
      (c) => c.usuario === usuario && c.clave === clave
    );

    if (!cajero) {
      return fail(400, { error: 'Usuario o clave incorrectos' });
    }

    // Crear una cookie de sesión
    cookies.set('session', cajero.usuario, {
      path: '/',
      httpOnly: true,
      sameSite: 'strict',
      secure: process.env.NODE_ENV === 'production',
      maxAge: 60 * 60 * 24  // 24 horas de duración
    });

    // Redirigir al dashboard del cajero
    throw redirect(303, `/${cajero.usuario}/inicio`);
  }
};
