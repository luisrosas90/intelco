<script lang="ts">
  import { onMount } from 'svelte';

  let cedula: string = '';
  let clientData = null;
  let errorMessage = '';
  let showReportButton = false;
  let valor: number | null = null;
  let valorConverted: string | null = null;
  let exchangeRate: number = 36.80;
  let referenceNumber: string = '';
  let phoneNumber: string = '';

  const fetchClientData = async () => {
    try {
      // Verifica que la cédula esté definida
      if (!cedula) {
        errorMessage = 'Por favor, ingrese una cédula válida';
        return;
      }

      const response = await fetch('/api/validar-reporte', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ cedula, referencia_pago: referenceNumber, monto: valor })
      });

      const data = await response.json();
      if (response.ok) {
        clientData = data.client;
        errorMessage = '';
      } else {
        errorMessage = data.mensaje || 'Error al validar el reporte';
      }
    } catch (error) {
      errorMessage = 'Hubo un problema al obtener los datos. Por favor, inténtalo de nuevo.';
      console.error('Error:', error);
    }
  };

  const submitPayment = async () => {
    if (!referenceNumber || !phoneNumber) {
      alert('Por favor, complete todos los campos para el pago.');
      return;
    }

    try {
      const response = await fetch('/api/payments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          cedula,
          valor,
          metodo_pago: 'Pago Móvil',
          referenceNumber,
          phoneNumber
        })
      });

      const result = await response.json();

      if (response.ok) {
        alert('Pago registrado exitosamente.');
      } else {
        alert('Error al registrar el pago: ' + result.mensaje);
      }
    } catch (error) {
      alert('Hubo un error al procesar el pago. Por favor, intenta de nuevo.');
    }
  };
</script>

<section class="w-full max-w-md px-5 py-6 mx-auto bg-white rounded-md shadow-md">
  <h2>Verificar Estado del Reporte</h2>
  <form on:submit|preventDefault={fetchClientData}>
    <label for="cedula">Cédula:</label>
    <input id="cedula" bind:value={cedula} required class="w-full p-2 border border-gray-300 rounded-md" />
    <button type="submit" class="mt-4 bg-blue-600 text-white px-4 py-2 rounded-md">Verificar</button>
  </form>

  {#if clientData}
    <div class="mt-6">
      <h3 class="text-lg font-semibold">Información del Cliente</h3>
      <p>Nombre: {clientData.nombre}</p>
      <p>Deuda: {valorConverted} Bs</p>

      {#if showReportButton}
        <div class="mt-4">
          <h4 class="text-md font-semibold">Reportar Pago</h4>

          <label for="reference" class="block mt-2">Número de Referencia</label>
          <input id="reference" bind:value={referenceNumber} class="w-full p-2 border border-gray-300 rounded-md" />

          <label for="phone" class="block mt-2">Número de Teléfono</label>
          <input id="phone" bind:value={phoneNumber} class="w-full p-2 border border-gray-300 rounded-md" />

          <button on:click={submitPayment} class="mt-4 bg-green-600 text-white px-4 py-2 rounded-md">
            Confirmar Pago Móvil
          </button>
        </div>
      {/if}
    </div>
  {/if}

  {#if errorMessage}
    <p class="mt-4 text-red-600">{errorMessage}</p>
  {/if}
</section>

<style>
  /* Aquí puedes aplicar los estilos existentes para mantener el diseño actual */
</style>
