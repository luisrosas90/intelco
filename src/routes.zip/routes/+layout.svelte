<script lang="ts">
import '../app.css';
  </script>
  
  <!-- Layout principal con la navegación lateral y el contenido -->
  <div class="flex h-screen bg-gray-100">
    
    <!-- Navegación lateral -->
    <aside class="w-64 bg-white p-6 shadow-md">
      <div class="text-center mb-8">
        <h2 class="text-xl font-bold text-green-500">BitePoint</h2>
      </div>
      <nav>
        <ul class="space-y-6">
          <li>
            <a href="/" class="flex items-center space-x-3 text-gray-600 hover:text-green-500">
              <svg class="w-6 h-6" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16m-7 6h7" />
              </svg>
              <span>Dashboard</span>
            </a>
          </li>
          <li>
            <a href="/menu" class="flex items-center space-x-3 text-gray-600 hover:text-green-500">
              <svg class="w-6 h-6" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16m-7 6h7" />
              </svg>
              <span>Menu</span>
            </a>
          </li>
          <!-- Agrega más elementos de navegación aquí -->
        </ul>
      </nav>
      <div class="mt-auto flex items-center space-x-4">
        <img src="https://via.placeholder.com/40" alt="User" class="w-10 h-10 rounded-full" />
        <div>
          <p class="font-semibold text-gray-700">Gladina Samantha</p>
          <p class="text-gray-400 text-sm">Waiter</p>
        </div>
      </div>
    </aside>
  
    <!-- Sección de contenido principal -->
    <main class="flex-1 p-6 overflow-y-auto">
      <slot />
    </main>
  </div>
  