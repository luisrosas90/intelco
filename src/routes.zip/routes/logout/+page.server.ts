import { redirect } from '@sveltejs/kit';

export const actions = {
  default: async ({ cookies }) => {
    // Limpiar la sesión del cajero
    cookies.delete('session');
    sessionStorage.removeItem('cajero');
    throw redirect(303, '/login');
  }
};
