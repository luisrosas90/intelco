<script>
    // Opcionalmente, puedes iniciar una redirección desde el frontend.
    import { goto } from '$app/navigation';
    
    goto('/login'); // Redirigir inmediatamente al login si se carga esta página
  </script>
  
  <p>Redirigiendo...</p>
  