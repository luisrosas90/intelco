<script lang="ts">
  import { onMount } from 'svelte';
  import jsPDF from 'jspdf';

  // Variables de estado y datos
  let cedula: string = '';
  let clientData: ClientData | null = null;
  let debtData: DebtData[] = [];
  let showReportButton: boolean = false;
  let showRegisterMessage = false;
  let showReportModal = false;
  let selectedBank: string = 'Paypal';
  let referenceNumber: string = '';
  let phoneNumber: string = '';
  let clientName: string = '';
  let clientAddress: string = '';
  let idFactura: number | null = null;
  let errorMessage: string = '';
  let totalFacturas: number | null = null;
  let totalFacturasConverted: string | null = null;
  let valor: number | null = null;
  let valorConverted: string | null = null;
  let exchangeRate: number = 36.80;

  // Configuración de notificación de WhatsApp
  const adminPhoneNumber = '+584245325586';
  const whatsappApiUrl = 'https://wabasms.com/api/send/whatsapp';

  // Interfaces para datos del cliente y deuda
  interface ClientData {
    id: number;
    nombre: string;
    estado: string;
    correo: string;
    telefono: string;
    movil: string;
    cedula: string;
    direccion_principal: string;
    facturacion: {
      facturas_nopagadas: number;
      total_facturas: string;
    };
    servicios: Array<{
      id: number;
      tiposervicio: string;
      direccion: string;
      perfil: string;
    }>;
  }

  interface DebtData {
    IDFactura: number;
    detalle: string;
    valor: number;
  }

  // Función para obtener la tasa de cambio
  const fetchExchangeRate = async () => {
    try {
      const response = await fetch('/api/exchange-rate');
      const data = await response.json();

      if (response.ok) {
        exchangeRate = data.exchangeRate;
        console.log('Tasa de cambio obtenida:', exchangeRate);
      } else {
        console.error('Error al obtener la tasa de cambio:', data.message);
        alert('Error al obtener la tasa de cambio: ' + data.message);
      }
    } catch (error) {
      console.error('Error al obtener la tasa de cambio:', error);
      alert('Error al obtener la tasa de cambio. Por favor, intenta de nuevo.');
    }
  };

  // Función para obtener los datos del cliente y su deuda
  const fetchClientAndDebtData = async () => {
    try {
      const response = await fetch('/api/clientes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ cedula })
      });

      const data = await response.json();

      if (response.ok) {
        clientData = data.client;
        debtData = data.debt;

        if (clientData) {
          clientName = clientData.nombre;
          clientAddress = clientData.direccion_principal;
          phoneNumber = clientData.telefono;

          if (clientData.facturacion.facturas_nopagadas > 0) {
            totalFacturas = parseFloat(clientData.facturacion.total_facturas);
            totalFacturasConverted = (totalFacturas * exchangeRate).toFixed(2);
            showReportButton = true;
          } else {
            alert('Su servicio se encuentra sin deuda. Gracias por preferirnos.');
            window.location.reload();
          }
        } else {
          showRegisterMessage = true;
          showReportButton = false;
        }

        if (debtData.length > 0) {
          idFactura = debtData[0].IDFactura;
          valor = debtData[0].valor;
          valorConverted = (valor * exchangeRate).toFixed(2);
        } else {
          console.warn('Operación exitosa, pero no se encontraron datos de deuda.');
          alert('Operación exitosa, pero no se encontraron datos de deuda.');
          window.location.reload();
        }

      } else {
        console.error('Error en la respuesta:', data.mensaje);
        errorMessage = data.mensaje;
      }

    } catch (error) {
      console.error('Error al consultar las APIs:', error);
      errorMessage = 'Hubo un problema al obtener los datos. Por favor, inténtalo de nuevo más tarde.';
    }
  };

  // Ejecutar al montar el componente
  onMount(() => {
    fetchExchangeRate();
  });

  // Función para enviar el pago
  const submitPayment = async () => {
    if (!idFactura || !valor) {
      alert('El ID de la factura y el valor son necesarios para procesar el pago.');
      return;
    }

    console.log('Datos de pago antes de enviar:', { IDFactura: idFactura, valor });


    try {
      const response = await fetch('/api/payments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          IDFactura: idFactura,
          valor: valor,
          fecha: new Date().toISOString().split('T')[0],
          secuencial: Math.floor(Math.random() * 900000000000) + 100000000000
        })
      });

      const result = await response.json();

      if (response.ok) {
        console.log('Pago registrado exitosamente:', result);
        alert('Pago registrado exitosamente.');
        showReportModal = false;
        await generateAndSaveReceipt(); // Generar y guardar el PDF
      } else {
        console.error('Error al registrar el pago:', result);
        alert('Error al registrar el pago: ' + result.mensaje);
      }
    } catch (error) {
      console.error('Error en la solicitud:', error);
      alert('Hubo un error al procesar el pago. Por favor, intenta de nuevo.');
    }
  };

  // Función para generar y guardar el recibo en PDF
  const generateAndSaveReceipt = async () => {
    if (!clientData || !valor) return;

    const doc = new jsPDF({
      unit: 'pt',
      format: [226.772, 841.89]
    });

    doc.setFontSize(18);
    const centerXLogo = (226.772 - 155) / 2;
    doc.addImage('/logo.png', 'PNG', centerXLogo, 20, 155, 65);
    doc.text('Recibo de Pago', 113.386, 90, { align: 'center' });
    doc.setLineWidth(0.5);
    doc.line(20, 100, 206.772, 100);
    doc.setFontSize(12);
    doc.text('Detalles del Cliente', 20, 120);
    doc.text(`Cliente: ${clientName}`, 20, 140);
    doc.text(`Cédula: ${cedula}`, 20, 160);
    doc.text(`Dirección: ${clientAddress}`, 20, 180);
    doc.text(`Teléfono: ${phoneNumber}`, 20, 200);
    doc.line(20, 210, 206.772, 210);
    doc.setFontSize(12);
    doc.text('Detalles del Pago', 20, 220);
    doc.text(`ID Factura: ${idFactura}`, 20, 235);
    doc.text(`Monto Ref USD: $${valor}`, 20, 250);
    doc.text(`Monto Pagado: ${valorConverted} Bs`, 20, 270);
    doc.text(`Pasarela: ${selectedBank}`, 20, 290);
    doc.text(`Número de Referencia: ${referenceNumber}`, 20, 310);
    doc.text(`Fecha de Pago: ${new Date().toLocaleDateString()}`, 20, 330);
    doc.text(`Hora de Emisión: ${new Date().toLocaleTimeString()}`, 20, 360);
    doc.line(20, 340, 206.772, 340);
    doc.setFontSize(10);
    doc.text('Gracias por su pago!', 113.386, 380, { align: 'center' });
    doc.setFont('Helvetica', 'bold');
    doc.text('Nota: Por favor guarde una foto de este recibo', 113.386, 400, { align: 'center' });

    const pdfData = doc.output('blob'); // Convertir el PDF a blob

    // Enviar el PDF al servidor para guardarlo
    const formData = new FormData();
    formData.append('pdf', pdfData, `recibo_${idFactura}.pdf`);

    await fetch('/api/receipts', {
      method: 'POST',
      body: formData
    });

    doc.save('Recibo_de_Pago.pdf'); // Descargar el PDF localmente
  };

  // Función para enviar notificación de WhatsApp
  const sendWhatsAppNotification = async () => {
    const chat = {
      secret: "7cdb86a8a6bef4706e7429ded878d8c16511758e",
      account: "1724748268c4ca4238a0b923820dcc509a6f75849b66cd91ecdc747",
      recipient: adminPhoneNumber,
      type: "text",
      message: `Solicitud de pago recibida:\n\nCliente: ${clientName}\nMonto: ${valor} Bs\nBanco: ${selectedBank}\nReferencia: ${referenceNumber}\nTeléfono: ${phoneNumber}\nDirección: ${clientAddress}\n\nPor favor, apruebe o rechace el pago.`
    };

    console.log('Parámetros a enviar a la API de WhatsApp:', chat);

    try {
      const response = await fetch('/api/proxy', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(chat)
      });

      console.log('Respuesta de la solicitud HTTP:', response);

      const result = await response.json();

      console.log('Resultado parseado de la respuesta:', result);

      if (response.ok) {
        console.log('Mensaje de WhatsApp enviado exitosamente:', result);
      } else {
        console.error('Error al enviar el mensaje de WhatsApp:', result);
      }
    } catch (error) {
      console.error('Error en la solicitud:', error);
    }
  };

  // Función para alternar la visualización del modal de reporte de pago
  const toggleReportModal = () => {
    showReportModal = !showReportModal;
  };
</script>

<section class="w-full max-w-md px-5 py-6 mx-auto bg-white rounded-md shadow-md dark:bg-gray-800">
  <div class="flex flex-col items-center">
    <form id="searchForm" on:submit|preventDefault={fetchClientAndDebtData} class="w-full">
      <label for="cedula" class="block text-lg font-medium text-gray-700 dark:text-gray-300 text-center mb-2">Cédula del Cliente</label>
      <input
        id="cedula"
        bind:value={cedula}
        required
        class="w-full py-3 pl-4 pr-4 text-gray-700 bg-white border border-gray-300 rounded-md dark:bg-gray-700 dark:text-gray-300 dark:border-gray-600 focus:border-blue-400 dark:focus:border-blue-300 focus:outline-none focus:ring focus:ring-blue-300 focus:ring-opacity-40"
      />
      <button
        type="submit"
        class="flex items-center justify-center w-full px-4 py-2 mt-4 font-medium tracking-wide text-white capitalize transition-colors duration-300 transform bg-gradient-to-r from-blue-600 to-blue-400 rounded-lg hover:from-blue-500 hover:to-blue-300 focus:outline-none focus:ring focus:ring-blue-300 focus:ring-opacity-80"
      >
        <svg class="w-5 h-5 mr-2" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
          <path fill-rule="evenodd" d="M4 2a1 1 0 011 1v2.101a7.002 7.002 0 0111.601 2.566 1 1 0 11-1.885.666A5.002 5.002 0 005.999 7H9a1 1 0 010 2H4a1 1 0 01-1-1V3a1 1 0 011-1zm.008 9.057a1 1 0 011.276.61A5.002 5.002 0 0014.001 13H11a1 1 0 110-2h5a1 1 0 011 1v5a1 1 0 11-2 0v-2.101a7.002 7.002 0 01-11.601-2.566 1 1 0 01.61-1.276z" clip-rule="evenodd" />
        </svg>
        <span>Buscar Cliente</span>
      </button>
    </form>
  </div>
</section>

{#if clientData}
  <div class="mt-6 p-4 bg-white rounded-lg shadow-md dark:bg-gray-800">
    <h3 class="text-lg font-medium text-gray-800 dark:text-gray-100">Información del Cliente</h3>
    <p class="text-gray-700 dark:text-gray-300">Nombre: {clientName}</p>
    <p class="text-gray-700 dark:text-gray-300">Dirección: {clientAddress}</p>
    <p class="text-gray-700 dark:text-gray-300">Teléfono: {phoneNumber}</p>
    <p class="text-gray-700 dark:text-gray-300">Estado: {clientData.estado}</p>
    <p class="text-gray-700 dark:text-gray-300">Correo: {clientData.correo}</p>
    <h4 class="mt-4 font-semibold text-gray-800 dark:text-gray-100">Servicios:</h4>
    {#each clientData.servicios as servicio}
      <p class="text-gray-700 dark:text-gray-300">{servicio.tiposervicio} - {servicio.direccion} ({servicio.perfil})</p>
    {/each}
    <p class="mt-2 font-semibold text-gray-800 dark:text-gray-100">Deuda Ref: ${valor}</p>
    <p class="text-gray-700 dark:text-gray-300">Deuda: {valorConverted} Bs</p>

    {#if showReportButton}
      <button
        on:click={toggleReportModal}
        class="mt-4 bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-300"
      >
        Reportar Pago
      </button>
    {/if}
  </div>
{/if}

{#if showRegisterMessage}
  <p class="mt-4 text-center text-red-600 font-medium">Cliente no encontrado. ¡Regístrate con nosotros!</p>
{/if}

{#if showReportModal}
  <div class="fixed inset-0 flex items-center justify-center bg-gray-800 bg-opacity-50 z-50">
    <div class="bg-white rounded-lg shadow-lg p-6 max-w-sm mx-auto">
      <h3 class="text-xl font-medium text-gray-800">Reportar Pago</h3>

      <div class="mt-4">
        <label for="totalFacturasConverted" class="block text-sm font-medium text-gray-700">Monto a Pagar:</label>
        <input type="text" id="amount" value={`${valorConverted} Bs`} readonly class="w-full px-4 py-2 mt-2 border rounded-md bg-gray-100 text-gray-600 cursor-not-allowed">
      </div>

      <div class="mt-4">
        <label for="bank" class="block text-sm font-medium text-gray-700">Selecciona el Banco:</label>
        <select id="bank" bind:value={selectedBank} class="w-full px-4 py-2 mt-2 border rounded-md">
          <option value="Paypal">Paypal</option>
          <option value="Efectivo">Efectivo</option>
          <option value="Banesco">Banesco</option>
          <option value="Provincial">Provincial</option>
          <option value="Mercantil">Mercantil</option>
        </select>
      </div>

      <div class="mt-4">
        <label for="reference" class="block text-sm font-medium text-gray-700">Número de Referencia:</label>
        <input type="text" id="reference" bind:value={referenceNumber} class="w-full px-4 py-2 mt-2 border rounded-md">
      </div>

      <div class="mt-4">
        <label for="phone" class="block text-sm font-medium text-gray-700">Número de Teléfono:</label>
        <input type="tel" id="phone" bind:value={phoneNumber} class="w-full px-4 py-2 mt-2 border rounded-md">
      </div>

      <div class="flex justify-end mt-4">
        <button
          class="bg-gray-500 text-white px-4 py-2 rounded mr-2 hover:bg-gray-400 focus:outline-none focus:ring-2 focus:ring-gray-300" 
          on:click={toggleReportModal}
        >
          Cancelar
        </button>
        <button
          class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-300" 
          on:click={submitPayment}
        >
          Confirmar Pago
        </button>
      </div>
    </div>
  </div>
{/if}

<style>
  .client-panel {
    padding: 20px;
    border: 1px solid #ccc;
    border-radius: 5px;
    max-width: 600px;
    margin: 20px auto;
  }

  .client-panel input,
  .client-panel select {
    width: calc(100% - 22px);
    padding: 10px;
    margin-bottom: 10px;
    border-radius: 3px;
    border: 1px solid #ddd;
  }

  .client-panel button {
    padding: 10px 15px;
    color: #fff;
    background-color: #007bff;
    border: none;
    border-radius: 3px;
    cursor: pointer;
  }

  .client-panel button:hover {
    background-color: #0056b3;
  }

  .client-panel .error-message {
    color: red;
    margin-bottom: 10px;
  }
</style>
