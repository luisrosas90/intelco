<!-- src/components/Dashboard.svelte -->
<script lang="ts">
    import { onMount } from 'svelte';
    import Header from './Header.svelte';
    import Pagos from './Pagos.svelte';
    import Historial from './Historial.svelte';
    import Recibos from './Recibos.svelte';
    import Reportes from './Reportes.svelte';
  
    let activeSection = 'historial';
    let usuario = 'Usuario de ejemplo'; // Simular usuario desde la sesión
  
    const changeSection = (section: string) => {
      activeSection = section;
    };
  
    onMount(() => {
      changeSection('historial'); // Cargar historial por defecto
    });
</script>

<Header {usuario} {changeSection} />

<!-- Contenido dinámico según la sección activa -->
{#if activeSection === 'historial'}
  <Pagos />
{:else if activeSection === 'pagos'}
 <Historial /> 
{:else if activeSection === 'recibos'}
  <Recibos />
{:else if activeSection === 'reportes'}
  <Reportes />
{/if}
