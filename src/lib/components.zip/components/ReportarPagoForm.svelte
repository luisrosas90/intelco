<!-- src/components/ReportarPagoForm.svelte -->
<script lang="ts">
    import jsPDF from 'jspdf';
    export let valorConverted: string;
  
    let selectedBank: string = 'Paypal';
    let referenceNumber: string = '';
    let phoneNumber: string = '';
    let cedula: string = ''; // Deberías pasar estos valores como props o manejar el estado global
    let clientName: string = '';
    let clientAddress: string = '';
    let idFactura: number | null = null;
    let clientData: any; // Define el tipo correcto según tu estructura
    let valor: number | null = null;
  
    const submitPayment = async () => {
      if (!idFactura || !valor) {
        alert('El ID de la factura y el valor son necesarios para procesar el pago.');
        return;
      }
  
      try {
        const response = await fetch('/api/payments', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            IDFactura: idFactura,
            valor: valor,
            fecha: new Date().toISOString().split('T')[0],
            secuencial: Math.floor(Math.random() * 900000000000) + 100000000000
          })
        });
  
        const result = await response.json();
  
        if (response.ok) {
          alert('Pago registrado exitosamente.');
          await generateAndSaveReceipt(); // Generar y guardar el PDF
        } else {
          alert('Error al registrar el pago: ' + result.mensaje);
        }
      } catch (error) {
        alert('Hubo un error al procesar el pago. Por favor, intenta de nuevo.');
      }
    };
  
    const generateAndSaveReceipt = async () => {
      if (!clientData || !valor) return;
  
      const doc = new jsPDF({
        unit: 'pt',
        format: [226.772, 841.89]
      });
  
      doc.setFontSize(18);
      const centerXLogo = (226.772 - 155) / 2;
      doc.addImage('/logo.png', 'PNG', centerXLogo, 20, 155, 65);
      doc.text('Recibo de Pago', 113.386, 90, { align: 'center' });
      doc.setLineWidth(0.5);
      doc.line(20, 100, 206.772, 100);
      doc.setFontSize(12);
      doc.text('Detalles del Cliente', 20, 120);
      doc.text(`Cliente: ${clientName}`, 20, 140);
      doc.text(`Cédula: ${cedula}`, 20, 160);
      doc.text(`Dirección: ${clientAddress}`, 20, 180);
      doc.text(`Teléfono: ${phoneNumber}`, 20, 200);
      doc.line(20, 210, 206.772, 210);
      doc.setFontSize(12);
      doc.text('Detalles del Pago', 20, 220);
      doc.text(`ID Factura: ${idFactura}`, 20, 235);
      doc.text(`Monto Ref USD: $${valor}`, 20, 250);
      doc.text(`Monto Pagado: ${valorConverted} Bs`, 20, 270);
      doc.text(`Pasarela: ${selectedBank}`, 20, 290);
      doc.text(`Número de Referencia: ${referenceNumber}`, 20, 310);
      doc.text(`Fecha de Pago: ${new Date().toLocaleDateString()}`, 20, 330);
      doc.text(`Hora de Emisión: ${new Date().toLocaleTimeString()}`, 20, 360);
      doc.line(20, 340, 206.772, 340);
      doc.setFontSize(10);
      doc.text('Gracias por su pago!', 113.386, 380, { align: 'center' });
      doc.setFont('Helvetica', 'bold');
      doc.text('Nota: Por favor guarde una foto de este recibo', 113.386, 400, { align: 'center' });
  
      const pdfData = doc.output('blob'); // Convertir el PDF a blob
  
      // Enviar el PDF al servidor para guardarlo
      const formData = new FormData();
      formData.append('pdf', pdfData, `recibo_${idFactura}.pdf`);
  
      await fetch('/api/receipts', {
        method: 'POST',
        body: formData
      });
  
      doc.save('Recibo_de_Pago.pdf'); // Descargar el PDF localmente
    };
  </script>
  
  <!-- Reportar Pago -->
  <div class="mt-6 p-4 bg-gray-100 rounded-lg shadow-md">
    <h3 class="text-xl font-medium text-gray-800 mb-4">Reportar Pago</h3>
  
    <!-- Monto a Pagar -->
    <div class="mb-4">
      <label for="totalFacturasConverted" class="block text-sm font-medium text-gray-700">Monto a Pagar:</label>
      <input type="text" id="amount" value={`${valorConverted} Bs`} readonly class="w-full px-4 py-2 mt-2 border rounded-md bg-gray-100 text-gray-600 cursor-not-allowed">
    </div>
  
    <!-- Selección de Banco -->
    <div class="mb-4">
      <label for="bank" class="block text-sm font-medium text-gray-700">Selecciona el Banco:</label>
      <select id="bank" bind:value={selectedBank} class="w-full px-4 py-2 mt-2 border rounded-md">
        <option value="Paypal">Paypal</option>
        <option value="Efectivo">Efectivo</option>
        <option value="Banesco">Banesco</option>
        <option value="Provincial">Provincial</option>
        <option value="Mercantil">Mercantil</option>
      </select>
    </div>
  
    <!-- Número de Referencia -->
    <div class="mb-4">
      <label for="reference" class="block text-sm font-medium text-gray-700">Número de Referencia:</label>
      <input type="text" id="reference" bind:value={referenceNumber} class="w-full px-4 py-2 mt-2 border rounded-md">
    </div>
  
    <!-- Número de Teléfono -->
    <div class="mb-4">
      <label for="phone" class="block text-sm font-medium text-gray-700">Número de Teléfono:</label>
      <input type="tel" id="phone" bind:value={phoneNumber} class="w-full px-4 py-2 mt-2 border rounded-md">
    </div>
  
    <!-- Botones de Confirmar y Cancelar -->
    <div class="flex justify-end mt-4">
      <button
        class="bg-gray-500 text-white px-4 py-2 rounded mr-2 hover:bg-gray-400 focus:outline-none focus:ring-2 focus:ring-gray-300" 
        on:click={() => { /* Lógica para cancelar */ }}
      >
        Cancelar
      </button>
      <button
        class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-300" 
        on:click={submitPayment}
      >
        Confirmar Pago
      </button>
    </div>
  </div>
  