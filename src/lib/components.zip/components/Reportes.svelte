<script lang="ts">
    import { onMount } from 'svelte';
  
    interface Reporte {
      fecha: string;
      descripcion: string;
      monto: number;
    }
  
    let reportes: Reporte[] = [];
  
    const fetchReportes = async () => {
      try {
        const response = await fetch('/api/reportes'); // Ajusta esta ruta si es necesario
        const data = await response.json();
        if (response.ok) {
          reportes = data.reportes;
        } else {
          alert('Error al obtener los reportes');
        }
      } catch (error) {
        console.error('Error al obtener los reportes:', error);
      }
    };
  
    onMount(() => {
      fetchReportes();
    });
  </script>
  
  <section>
    <h2 class="text-xl font-bold mb-4">Reportes</h2>
    {#if reportes.length > 0}
      <ul>
        {#each reportes as reporte}
          <li>{reporte.fecha} - {reporte.descripcion} - {reporte.monto} Bs</li>
        {/each}
      </ul>
    {:else}
      <p>No hay reportes disponibles.</p>
    {/if}
  </section>
  