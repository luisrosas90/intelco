<script lang="ts">
    import { onMount } from 'svelte';
  
    interface HistorialEntry {
      fecha: string;
      descripcion: string;
      monto: number;
    }
  
    let historial: HistorialEntry[] = [];
  
    const fetchHistorial = async () => {
      try {
        const response = await fetch('/api/historial'); // Ajusta esta ruta si es necesario
        const data = await response.json();
        if (response.ok) {
          historial = data.historial;
        } else {
          alert('Error al obtener el historial');
        }
      } catch (error) {
        console.error('Error al obtener el historial:', error);
      }
    };
  
    onMount(() => {
      fetchHistorial();
    });
  </script>
  
  <section>
    <h2 class="text-xl font-bold mb-4">Historial</h2>
    {#if historial.length > 0}
      <ul>
        {#each historial as entry}
          <li>{entry.fecha} - {entry.descripcion} - {entry.monto} Bs</li>
        {/each}
      </ul>
    {:else}
      <p>No hay historial disponible.</p>
    {/if}
  </section>
  