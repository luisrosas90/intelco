<!-- src/components/Header.svelte -->
<script lang="ts">
    export let usuario: string; // Aceptar la prop `usuario`
  export let changeSection: (section: string) => void; // Aceptar la prop `changeSection`
</script>

<div class="flex justify-between items-center mb-8">
  <h1 class="text-2xl font-bold">Bienvenido, {usuario} al panel de cajeros</h1>
  <div class="flex space-x-4">
    <button class="bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-500" on:click={() => changeSection('pagos')}>
        Pagos
      </button>
    <button class="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-500" on:click={() => changeSection('historial')}>
      Historial
    </button>
    <button class="bg-yellow-600 text-white px-4 py-2 rounded-md hover:bg-yellow-500" on:click={() => changeSection('recibos')}>
      Recibos
    </button>
    <button class="bg-red-600 text-white px-4 py-2 rounded-md hover:bg-red-500" on:click={() => changeSection('reportes')}>
      Reportes
    </button>
  </div>
</div>