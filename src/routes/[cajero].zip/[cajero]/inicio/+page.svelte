<script>
    let cedula = '';
    let clientData = null;
  
    async function buscarCliente() {
      const response = await fetch('/api/clientes', {
        method: 'POST',
        body: JSON.stringify({ cedula })
      });
      clientData = await response.json();
    }
  </script>
  
  <section>
    <div class="bg-gradient-to-r from-purple-500 to-pink-500 p-8 text-white text-center">
      <h1 class="text-5xl font-bold">10,000,000 TIP</h1>
      <p class="text-lg mt-2">Today's Sales for {cajero}</p>
      
    <input type="text" bind:value={cedula} placeholder="Cédula del Cliente" />
    <button on:click={buscarCliente}>Buscar Cliente</button>
  
    {#if clientData}
      <p>Nombre: {clientData.nombre}</p>
      <p>Dirección: {clientData.direccion}</p>
      <!-- Mostrar más datos del cliente -->
    {/if}
  </section>
  