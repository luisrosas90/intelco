<script lang="ts">
  import { onMount } from 'svelte';  // <-- Agrega esta línea

  let historialPagos = [];

  const fetchHistorialPagos = async () => {
    try {
      const response = await fetch('/api/payments/historial');
      const data = await response.json();
      if (response.ok) {
        historialPagos = data.pagos;
      } else {
        alert('Error al cargar el historial de pagos.');
      }
    } catch (error) {
      console.error('Error al cargar el historial de pagos:', error);
    }
  };

  onMount(() => {
    fetchHistorialPagos();
  });
</script>
