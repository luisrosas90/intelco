import { redirect } from '@sveltejs/kit';
import { getUserRoleFromSession } from '$lib/utils/session';

export const load = async ({ cookies }) => {
  const sessionCookie = cookies.get('session');

  if (!sessionCookie) {
    // Si no hay cookie de sesión, redirigir al login
    throw redirect(303, '/login');
  }

  let session;

  try {
    // Parsear la cookie de sesión
    session = JSON.parse(sessionCookie);
  } catch (error) {
    console.error('Error al parsear la cookie de sesión:', error);
    throw redirect(303, '/login');
  }

  // Verificar que la sesión contenga el usuario
  if (!session.user) {
    console.error('Sesión inválida: falta el usuario');
    throw redirect(303, '/login');
  }

  // Obtener el rol del usuario desde la sesión
  const userRole = getUserRoleFromSession(session);

  if (userRole !== 'cajero') {
    // Si el rol no es de cajero, redirigir al login
    throw redirect(303, '/login');
  }

  // Devolver los datos del usuario al layout
  return {
    user: session.user // Devolver el usuario de la sesión al layout
  };
};
