<script>
  import jsPDF from 'jspdf';
  let totalRecibido = 0; // Aquí puedes cargar el total de los pagos del día desde el estado global o base de datos.

  function generarReporte() {
    const doc = new jsPDF();
    doc.text("Reporte Diario de Pagos", 10, 10);
    doc.text("Total Recibido: " + totalRecibido + " VES", 10, 20);
    doc.save('reporte-diario.pdf');
  }
</script>

<section>
  <h2>Generar Reporte Diario</h2>
  <button on:click={generarReporte}>Imprimir Reporte Diario</button>
</section>
