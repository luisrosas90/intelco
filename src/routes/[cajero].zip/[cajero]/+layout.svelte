<script lang="ts">
  export let data; // Datos del cajero autenticado
</script>

<nav>
  <ul>
    <!-- Usamos los datos del usuario para generar las rutas dinámicas -->
    <li><a href="/{data.user}/inicio">Inicio</a></li>
    <li><a href="/{data.user}/pagos">Pagos</a></li>
  </ul>
</nav>

<!-- Formulario para cerrar sesión -->
<form method="POST" action="/logout">
  <button type="submit">Cerrar Sesión</button>
</form>

<!-- Slot para el contenido dinámico -->
<slot />
