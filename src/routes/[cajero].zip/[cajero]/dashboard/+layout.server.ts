import { redirect } from '@sveltejs/kit';
import type { LayoutServerLoad } from './$types';

export const load: LayoutServerLoad = async ({ cookies }) => {
  const sessionCookie = cookies.get('session');  // Obtener la cookie de sesión

  if (!sessionCookie) {
    // Si no hay cookie de sesión, redirigir al login
    throw redirect(303, '/login');
  }

  let session;

  try {
    // Parsear la cookie de sesión solo si es un JSON válido
    session = JSON.parse(sessionCookie);
  } catch (error) {
    console.error('Error al parsear la cookie de sesión:', error);
    throw redirect(303, '/login');  // Si falla el parseo, redirigir al login
  }

  // Verificar si el rol o el usuario son válidos
  if (!session || session.role !== 'cajero') {
    // Redirigir si no es un cajero
    throw redirect(303, '/login');
  }

  // Permitir el acceso si el usuario es un cajero
  return { session };
};
