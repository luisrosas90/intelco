<script lang="ts">
  import { onMount } from 'svelte';
  import jsPDF from 'jspdf';
  import type { ClientData, DebtData } from '$lib/types';

  let cedula: string = '';
  let clientData: ClientData | null = null;
  let debtData: DebtData[] = [];
  let showReportButton: boolean = false;
  let showRegisterMessage = false;
  let selectedBank: string = 'Paypal';
  let referenceNumber: string = '';
  let phoneNumber: string = '';
  let clientName: string = '';
  let clientAddress: string = '';
  let idFactura: number | null = null;
  let errorMessage: string = '';
  let totalFacturas: number | null = null;
  let totalFacturasConverted: string | null = null;
  let valor: number | null = null;
  let valorConverted: string | null = null;
  let exchangeRate: number = 36.80;

  // Sección agregada para la sesión
  export let session;
  let usuario = session.user; // Obtener el usuario de la sesión

  const fetchExchangeRate = async () => {
    try {
      const response = await fetch('/api/exchange-rate');
      const data = await response.json();

      if (response.ok) {
        exchangeRate = data.exchangeRate;
      } else {
        console.error('Error al obtener la tasa de cambio:', data.message);
        alert('Error al obtener la tasa de cambio: ' + data.message);
      }
    } catch (error) {
      console.error('Error al obtener la tasa de cambio:', error);
      alert('Error al obtener la tasa de cambio. Por favor, intenta de nuevo.');
    }
  };

  const fetchClientAndDebtData = async () => {
    try {
      const response = await fetch('/api/clientes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ cedula })
      });

      const data = await response.json();

      if (response.ok) {
        clientData = data.client;
        debtData = data.debt;

        if (clientData) {
          clientName = clientData.nombre;
          clientAddress = clientData.direccion_principal;
          phoneNumber = clientData.telefono;

          if (clientData.facturacion.facturas_nopagadas > 0) {
            totalFacturas = parseFloat(clientData.facturacion.total_facturas);
            totalFacturasConverted = (totalFacturas * exchangeRate).toFixed(2);
            showReportButton = true;
          } else {
            alert('Su servicio se encuentra sin deuda. Gracias por preferirnos.');
            window.location.reload();
          }
        } else {
          showRegisterMessage = true;
          showReportButton = false;
        }

        if (debtData.length > 0) {
          idFactura = debtData[0].IDFactura;
          valor = debtData[0].valor;
          valorConverted = (valor * exchangeRate).toFixed(2);
        } else {
          alert('Operación exitosa, pero no se encontraron datos de deuda.');
          window.location.reload();
        }

      } else {
        errorMessage = data.mensaje;
      }

    } catch (error) {
      errorMessage = 'Hubo un problema al obtener los datos. Por favor, inténtalo de nuevo más tarde.';
    }
  };

  onMount(() => {
    fetchExchangeRate();
  });

  const submitPayment = async () => {
    if (!idFactura || !valor) {
      alert('El ID de la factura y el valor son necesarios para procesar el pago.');
      return;
    }

    try {
      const response = await fetch('/api/payments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          IDFactura: idFactura,
          valor: valor,
          fecha: new Date().toISOString().split('T')[0],
          secuencial: Math.floor(Math.random() * 900000000000) + 100000000000
        })
      });

      const result = await response.json();

      if (response.ok) {
        alert('Pago registrado exitosamente.');
        await generateAndSaveReceipt(); // Generar y guardar el PDF
      } else {
        alert('Error al registrar el pago: ' + result.mensaje);
      }
    } catch (error) {
      alert('Hubo un error al procesar el pago. Por favor, intenta de nuevo.');
    }
  };

  const generateAndSaveReceipt = async () => {
    const doc = new jsPDF();
    doc.text("Recibo de Pago", 10, 10);
    doc.save("recibo.pdf");
  };
</script>

<!-- Encabezado del dashboard con el nombre del usuario -->
<div class="flex justify-between items-center mb-8">
  <h1 class="text-2xl font-bold">Bienvenido, {usuario} al panel de cajeros</h1>
  <div class="flex space-x-4">
    <button class="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-500">Historial</button>
    <button class="bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-500">Pagos</button>
    <button class="bg-yellow-600 text-white px-4 py-2 rounded-md hover:bg-yellow-500">Recibos</button>
    <button class="bg-red-600 text-white px-4 py-2 rounded-md hover:bg-red-500">Reportes</button>
  </div>
</div>

<!-- Tarjetas de resumen -->
<div class="grid grid-cols-3 gap-4 mb-8">
  <div class="bg-white p-6 shadow-md rounded-lg">
    <p class="text-sm text-gray-500">Tasa de Cambio Actual</p>
    <h2 class="text-3xl font-bold">{exchangeRate} Bs/USD</h2>
  </div>

  <div class="bg-white p-6 shadow-md rounded-lg">
    <p class="text-sm text-gray-500">Total Facturas Pendientes</p>
    <h2 class="text-3xl font-bold">{totalFacturasConverted} Bs</h2>
  </div>
</div>

<!-- Formulario de búsqueda de cliente -->
<section class="w-full max-w-md px-5 py-6 mx-auto bg-white rounded-md shadow-md">
  <!-- Formulario para buscar cliente -->
  <div class="flex flex-col items-center">
    <form id="searchForm" on:submit|preventDefault={fetchClientAndDebtData} class="w-full">
      <label for="cedula" class="block text-lg font-medium text-gray-700 text-center mb-2">Cédula del Cliente</label>
      <input
        id="cedula"
        bind:value={cedula}
        required
        class="w-full py-3 pl-4 pr-4 text-gray-700 bg-white border border-gray-300 rounded-md focus:border-blue-400 focus:outline-none focus:ring focus:ring-blue-300"
      >
      <button
        type="submit"
        class="flex items-center justify-center w-full px-4 py-2 mt-4 font-medium tracking-wide text-white capitalize transition-colors duration-300 transform bg-blue-600 rounded-lg hover:bg-blue-500 focus:outline-none"
      >
        Buscar Cliente
      </button>
    </form>
  </div>
</section>

{#if clientData}
  <!-- Información del cliente -->
  <div class="mt-6 p-4 bg-white rounded-lg shadow-md">
    <h3 class="text-lg font-medium text-gray-800">Información del Cliente</h3>
    <p class="text-gray-700">Nombre: {clientName}</p>
    <p class="text-gray-700">Dirección: {clientAddress}</p>
    <p class="text-gray-700">Teléfono: {phoneNumber}</p>
    <p class="text-gray-700">Estado: {clientData.estado}</p>
    <p class="text-gray-700">Correo: {clientData.correo}</p>
    <h4 class="mt-4 font-semibold text-gray-800">Servicios:</h4>
    {#each clientData.servicios as servicio}
      <p class="text-gray-700">{servicio.tiposervicio} - {servicio.direccion} ({servicio.perfil})</p>
    {/each}
    <p class="mt-2 font-semibold text-gray-800">Deuda Ref: ${valor}</p>
    <p class="text-gray-700">Deuda: {valorConverted} Bs</p>

    {#if showReportButton}
      <!-- Reportar Pago -->
      <div class="mt-6 p-4 bg-gray-100 rounded-lg shadow-md">
        <h3 class="text-xl font-medium text-gray-800 mb-4">Reportar Pago</h3>

        <!-- Monto a Pagar -->
        <div class="mb-4">
          <label for="totalFacturasConverted" class="block text-sm font-medium text-gray-700">Monto a Pagar:</label>
          <input type="text" id="amount" value={`${valorConverted} Bs`} readonly class="w-full px-4 py-2 mt-2 border rounded-md bg-gray-100 text-gray-600 cursor-not-allowed">
        </div>

        <!-- Selección de Banco -->
        <div class="mb-4">
          <label for="bank" class="block text-sm font-medium text-gray-700">Selecciona el Banco:</label>
          <select id="bank" bind:value={selectedBank} class="w-full px-4 py-2 mt-2 border rounded-md">
            <option value="Paypal">Paypal</option>
            <option value="Efectivo">Efectivo</option>
            <option value="Banesco">Banesco</option>
            <option value="Provincial">Provincial</option>
            <option value="Mercantil">Mercantil</option>
          </select>
        </div>

        <!-- Número de Referencia -->
        <div class="mb-4">
          <label for="reference" class="block text-sm font-medium text-gray-700">Número de Referencia:</label>
          <input type="text" id="reference" bind:value={referenceNumber} class="w-full px-4 py-2 mt-2 border rounded-md">
        </div>

        <!-- Número de Teléfono -->
        <div class="mb-4">
          <label for="phone" class="block text-sm font-medium text-gray-700">Número de Teléfono:</label>
          <input type="tel" id="phone" bind:value={phoneNumber} class="w-full px-4 py-2 mt-2 border rounded-md">
        </div>

        <!-- Botones de Confirmar y Cancelar -->
        <div class="flex justify-end mt-4">
          <button
            class="bg-gray-500 text-white px-4 py-2 rounded mr-2 hover:bg-gray-400 focus:outline-none focus:ring-2 focus:ring-gray-300" 
            on:click={() => { showReportButton = false }}
          >
            Cancelar
          </button>
          <button
            class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-300" 
            on:click={submitPayment}
          >
            Confirmar Pago
          </button>
        </div>
      </div>
    {/if}
  </div>
{/if}

{#if showRegisterMessage}
  <p class="mt-4 text-center text-red-600 font-medium">Cliente no encontrado. ¡Regístrate con nosotros!</p>
{/if}

