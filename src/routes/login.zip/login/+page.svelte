<script lang="ts">
  let usuario = '';
  let clave = '';
  let errorMessage = '';

  const iniciarSesion = async () => {
    const formData = new FormData();
    formData.append('usuario', usuario);
    formData.append('clave', clave);

    try {
      const response = await fetch('/login', {
        method: 'POST',
        body: formData // Cambiado a formData
      });

      if (response.ok) {
        // Redirigir al dashboard
        window.location.href = `/${usuario}/dashboard`;
      } else {
        errorMessage = 'Credenciales incorrectas. Por favor, inténtalo de nuevo.';
      }
    } catch (error) {
      errorMessage = 'Error en el servidor.';
    }
  };
</script>

<form on:submit|preventDefault={iniciarSesion}>
  <label for="usuario">Usuario</label>
  <input type="text" bind:value={usuario} required />

  <label for="clave">Clave</label>
  <input type="password" bind:value={clave} required />

  <button type="submit">Iniciar Sesión</button>

  {#if errorMessage}
    <p>{errorMessage}</p>
  {/if}
</form>
