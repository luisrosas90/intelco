import type { RequestHandler } from '@sveltejs/kit';
import { json } from '@sveltejs/kit';

const API_URL = 'https://panel.corpintelco.com/api/v1/PaidInvoice';
const TOKEN = 'YjQ4cmZEZHQyNnBNQ2Z5d0R4R1NnUT09'; // Token de acceso a la API

export const POST: RequestHandler = async ({ request }) => {
  try {
    // Extraemos los datos del cuerpo de la solicitud
    const { IDFactura, valor, fecha, secuencial, pasarela } = await request.json();
    console.log('Datos recibidos:', { IDFactura, valor, fecha, secuencial, pasarela });

    // Validamos que todos los campos obligatorios estén presentes
    if (!IDFactura || !valor || !fecha || !secuencial || !pasarela) {
      return json({ mensaje: 'Todos los campos son obligatorios.' }, { status: 400 });
    }

    // Creamos el payload que será enviado a la API externa
    const payload = {
      token: TOKEN,
      idfactura: IDFactura,
      pasarela: pasarela,  // 'Paypal', 'Zelle', etc., dependiendo de lo que elijas
      cantidad: valor,
      idtransaccion: secuencial
    };

    console.log('Payload a enviar:', payload);

    // Enviamos la solicitud a la API externa
    const response = await fetch(API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });

    console.log('Respuesta de la API externa:', response.status);

    // Procesamos la respuesta de la API externa
    const data = await response.json();
    console.log('Datos de respuesta de la API externa:', data);

    // Si el estado de la respuesta es éxito, respondemos con éxito
    if (data.estado === 'exito') {
      return json({ mensaje: 'Pago registrado exitosamente.' });
    } else {
      // Si la API externa devuelve un error, respondemos con ese error
      return json({ mensaje: data.mensaje || 'Error al registrar el pago.' }, { status: 400 });
    }
  } catch (error) {
    console.error('Error en el servidor:', error);
    // Si hay un error en el servidor o la solicitud falló, devolvemos un error 500
    return json({ mensaje: 'Error en el servidor. Por favor, inténtalo de nuevo más tarde.' }, { status: 500 });
  }
};
