import mysql from 'mysql2/promise';

// Configura la conexión con tus credenciales
export const pool = mysql.createPool({
  host: 'localhost',
  user: 'reporte',
  password: 'Lam1414*$',
  database: 'reporte',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
});