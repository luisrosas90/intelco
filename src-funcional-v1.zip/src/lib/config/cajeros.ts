// $lib/config/cajeros.ts
interface Cajero {
  usuario: string;
  clave: string;
  token: string;
}

export const cajerosConfig: { [key: string]: Cajero } = {
  cajero1: {
    usuario: 'cajero1',
    clave: '17550593',
    token: 'YjQ4cmZEZHQyNnBNQ2Z5d0R4R1NnUT09'
  },
  cajero2: {
    usuario: 'cajero2',  // Ahora 'mantecal' está correctamente definido aquí
    clave: 'clave2',
    token: 'RUpSZTZKc25jSStCNzdOOEFrU3pyZz09'
  },
  cajero3: {
    usuario: 'cajero3',
    clave: 'clave3',
    token: 'RVBvQ0ZKL2d6WmpaTDI1L0lyVHdUUT09'
  },
  cajero4: {
    usuario: 'cajero4',
    clave: 'clave4',
    token: 'YjQ4cmZEZHQyNnBNQ2Z5d0R4R1NnUT09'
  },
  cajero5: {
    usuario: 'cajero5',
    clave: 'clave5',
    token: 'TOKEN_UNICO_CAJERO5'
  },
  cajero6: {
    usuario: 'cajero6',
    clave: 'clave6',
    token: 'TOKEN_UNICO_CAJERO6'
  },
  cajero7: {
    usuario: 'cajero7',
    clave: 'clave7',
    token: 'TOKEN_UNICO_CAJERO7'
  },
  // Más cajeros...
};
