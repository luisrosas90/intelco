<script lang="ts">
  import { onMount } from 'svelte';

  interface Historial {
    tipo_operacion: string;
    monto: number;
    motivo: string;
    fecha: string;
  }

  let historial: Historial[] = [];
  let errorMessage = '';

  // Función para obtener el historial
  const fetchHistorial = async () => {
    try {
      const response = await fetch('/api/cajeros/historial'); // Ruta corregida para historial de cajeros
      const data = await response.json();

      console.log('Datos recibidos del historial:', data); // Depuración: Verifica la respuesta del servidor

      if (response.ok && data.success) {
        historial = data.historial || [];
        if (historial.length === 0) {
          errorMessage = 'No hay historial disponible.';
        }
      } else {
        errorMessage = data.message || 'Error al obtener el historial.';
      }
    } catch (error) {
      errorMessage = 'Error al conectar con el servidor para obtener el historial.';
      console.error('Error al obtener el historial:', error); // Depuración
    }
  };

  // Ejecutar la función al montar el componente
  onMount(() => {
    fetchHistorial();
  });
</script>

<section>
  <h2 class="text-xl font-bold mb-4">Historial de Operaciones</h2>

  {#if errorMessage}
    <p class="text-red-500">{errorMessage}</p>
  {/if}

  {#if historial.length > 0}
    <ul class="divide-y divide-gray-300">
      {#each historial as operacion}
        <li class="py-2">
          <p><strong>Operación:</strong> {operacion.tipo_operacion}</p>
          <p><strong>Monto:</strong> {operacion.monto.toFixed(2)} Bs</p>
          <p><strong>Motivo:</strong> {operacion.motivo}</p>
          <p><strong>Fecha:</strong> {new Date(operacion.fecha).toLocaleString()}</p>
        </li>
      {/each}
    </ul>
  {:else if !errorMessage}
    <p>No hay historial disponible en este momento.</p>
  {/if}
</section>

<style>
  ul {
    list-style: none;
    padding: 0;
    margin: 0;
  }

  li {
    padding: 1rem;
    background-color: #f9f9f9;
    border-radius: 8px;
    margin-bottom: 1rem;
  }

  .text-red-500 {
    color: #f87171;
  }

  .text-xl {
    font-size: 1.25rem;
    font-weight: bold;
  }

  .font-bold {
    font-weight: bold;
  }

  .mb-4 {
    margin-bottom: 1rem;
  }

  .divide-y {
    border-bottom: 1px solid #e5e7eb;
  }

  .divide-gray-300 {
    border-color: #d1d5db;
  }
</style>
