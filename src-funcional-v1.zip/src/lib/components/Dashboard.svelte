<script lang="ts">
  import { onMount } from 'svelte';
  import Header from './Header.svelte';
  import Pagos from './Pagos.svelte';
  import Historial from './Historial.svelte';
  import Recibos from './Recibos.svelte';
  import Reportes from './Reportes.svelte';

  let activeSection = 'historial';
  let usuario = 'Usuario de ejemplo'; // Simular usuario desde la sesión

  // Cambiar la sección activa cuando el usuario selecciona una opción
  const changeSection = (section: string) => {
    activeSection = section;
  };

  // Cargar la sección de historial por defecto al montar el componente
  onMount(() => {
    changeSection('historial');
  });
</script>

<!-- Encabezado con el nombre del usuario y control de navegación -->
<Header {usuario} {changeSection} />

<!-- Contenido dinámico basado en la sección activa -->
<section>
  {#if activeSection === 'pagos'}
    <Pagos />
  {:else if activeSection === 'historial'}
    <Historial />
  {:else if activeSection === 'recibos'}
    <Recibos />
  {:else if activeSection === 'reportes'}
    <Reportes />
  {/if}
</section>

<style>
  section {
    padding: 1rem;
    background-color: #f9f9f9;
    border-radius: 8px;
    margin-top: 1rem;
  }
</style>
