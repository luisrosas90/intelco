<script lang="ts">
  import { onMount } from 'svelte';

  interface Recibo {
    fecha: string;
    monto: number;
    metodo_pago: string;
    pdfUrl: string; // Agregamos la URL del PDF
  }

  let cedula: string = '';
  let recibos: Recibo[] = [];
  let errorMessage: string = '';

  const fetchRecibos = async () => {
    try {
      const response = await fetch(`/api/recibos?cedula=${cedula}`);
      const data = await response.json();
      if (response.ok) {
        recibos = data.recibos;
      } else {
        errorMessage = data.mensaje || 'Error al obtener los recibos';
      }
    } catch (error) {
      console.error('Error al obtener los recibos:', error);
      errorMessage = 'Error al conectar con el servidor para obtener los recibos.';
    }
  };
</script>

<section>
<h2 class="text-xl font-bold mb-4">Recibos</h2>

<!-- Formulario para buscar recibos por cliente -->
<div class="w-full max-w-md px-5 py-6 mx-auto bg-white rounded-md shadow-md">
  <form id="recibosSearchForm" on:submit|preventDefault={fetchRecibos} class="w-full">
    <label for="cedulaRecibo" class="block text-lg font-medium text-gray-700 text-center mb-2">Cédula del Cliente</label>
    <input
      id="cedulaRecibo"
      bind:value={cedula}
      required
      class="w-full py-3 pl-4 pr-4 text-gray-700 bg-white border border-gray-300 rounded-md focus:border-blue-400 focus:outline-none focus:ring focus:ring-blue-300"
    >
    <button
      type="submit"
      class="flex items-center justify-center w-full px-4 py-2 mt-4 font-medium tracking-wide text-white capitalize transition-colors duration-300 transform bg-yellow-600 rounded-lg hover:bg-yellow-500 focus:outline-none"
    >
      Buscar Recibos
    </button>
  </form>
</div>

{#if recibos.length > 0}
  <ul class="mt-4">
    {#each recibos as recibo}
      <li class="py-2 border-b">
        {recibo.fecha} - {recibo.monto} Bs - {recibo.metodo_pago} 
        <a href={recibo.pdfUrl} target="_blank" class="text-blue-600 underline ml-4">Descargar Recibo</a>
      </li>
    {/each}
  </ul>
{:else if errorMessage}
  <p class="text-red-500 mt-4">{errorMessage}</p>
{:else}
  <p class="mt-4">No se encontraron recibos para este cliente.</p>
{/if}
</section>

<style>
ul {
  list-style: none;
  padding: 0;
}
li {
  padding: 1rem;
  border-bottom: 1px solid #ddd;
}
.text-red-500 {
  color: red;
}
</style>
