// import { json } from '@sveltejs/kit';
// import { pool } from '$lib/db'; // Asegúrate de tener configurada la conexión a la base de datos

// export const POST = async ({ request }) => {
//   try {
//     // Extraer los datos de la solicitud
//     const { cliente_id, referencia_pago, monto } = await request.json();

//     // Validación de los datos
//     if (!cliente_id || !referencia_pago || !monto) {
//       return json({ success: false, message: 'Todos los campos son obligatorios' }, { status: 400 });
//     }

//     // Insertar el reporte de pago en la tabla
//     const [result] = await pool.execute(
//       `INSERT INTO reportes_pendientes (cliente_id, referencia_pago, monto, estado) VALUES (?, ?, ?, 'pendiente')`,
//       [cliente_id, referencia_pago, monto]
//     );

//     // Enviar respuesta de éxito
//     return json({ success: true, reporteId: result.insertId });
//   } catch (error) {
//     console.error('Error al crear el reporte pendiente:', error);
//     return json({ success: false, message: 'Error al crear el reporte' }, { status: 500 });
//   }
// };


import { json } from '@sveltejs/kit';
import { pool } from '$lib/db'; // Suponiendo que usas una base de datos

import type { RequestEvent } from '@sveltejs/kit';

import { sendWhatsAppMessage } from '../proxy/+server'; // Importar la función de envío de WhatsApp

// Función que maneja la solicitud POST para reportar pagos
export const POST = async ({ request }: RequestEvent) => {
    try {
        const { clienteId, nombreCliente, montoEnUsd, facturaId, selectedMethod, referenceNumber, banco, telefono } = await request.json();

        // Validación de datos esenciales
        if (!clienteId || !montoEnUsd || !facturaId || !referenceNumber || !banco || !telefono) {
            return json({ message: 'Faltan datos obligatorios.' }, { status: 400 });
        }

        // Insertar los datos del pago en la base de datos
        const estado = 'pendiente de validación';
        const [result] = await pool.execute(
            `
            INSERT INTO reportes_pagos (cliente_id, metodo_pago, monto, factura_id, estado, referencia_pago, moneda, telefono, banco)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            `,
            [clienteId, selectedMethod, montoEnUsd, facturaId, estado, referenceNumber, 'USD', telefono, banco]
        );

        // Enviar mensaje de WhatsApp al admin con el enlace para validar el pago
        const adminPhoneNumber = process.env.ADMIN_PHONE; // Define el número del admin en las variables de entorno
        const reportUrl = `https://reporte.corpintelco.com/admin/reportes`; // Enlace a la página de validación

        const whatsappMessage = `Nuevo pago reportado:
        - Cliente: ${nombreCliente}
        - Monto: ${montoEnUsd} USD
        - Banco: ${banco}
        - Referencia: ${referenceNumber}
        - Teléfono: ${telefono}
        
        Valida el reporte en: ${reportUrl}`;

        const whatsappResponse = await sendWhatsAppMessage({
            recipient: adminPhoneNumber,
            message: whatsappMessage
        });

        if (!whatsappResponse.ok) {
            const errorDetails = await whatsappResponse.json();
            console.error('Error al enviar el mensaje de WhatsApp:', errorDetails);
            return json({ message: 'Error al registrar el pago, pero el pago fue registrado correctamente.' }, { status: 500 });
        }

        return json({ message: 'Pago registrado y notificación enviada correctamente.' }, { status: 200 });

    } catch (error) {
        console.error('Error al procesar el pago:', error);
        return json({ message: 'Error al procesar el pago.' }, { status: 500 });
    }
};

