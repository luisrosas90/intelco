// src/routes/api/operaciones/+server.ts
import type { RequestHandler } from '@sveltejs/kit';
import { json } from '@sveltejs/kit';
import { pool } from '$lib/db'; 

interface Operacion {
  id: number;
  fecha: string;
  tipo: string;
  monto: number;
  descripcion?: string;
}

export const GET: RequestHandler = async () => {

  try {
    const [rows] = await pool.execute('SELECT * FROM operaciones');
    return json({ operaciones: rows });
  } catch (error) {
    console.error('Error al interactuar con la base de datos:', error);
    return json({ mensaje: 'Error al interactuar con la base de datos.' }, { status: 500 });
  }
};
