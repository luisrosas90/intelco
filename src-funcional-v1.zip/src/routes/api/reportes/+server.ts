import { pool } from '$lib/db'; // Asegúrate de que el pool de la base de datos esté configurado correctamente
import { json } from '@sveltejs/kit';

export const GET = async () => {
  try {
    // Consulta a la base de datos para obtener los reportes del día
    const [rows] = await pool.query('SELECT * FROM reportes WHERE fecha = CURDATE()');
    
    return json({ reportes: rows });
  } catch (error) {
    console.error('Error al obtener los reportes:', error);
    return json({ mensaje: 'Error al obtener los reportes.' }, { status: 500 });
  }
};
