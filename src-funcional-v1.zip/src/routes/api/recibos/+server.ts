import { pool } from '../../../lib/db'; 
import { json } from '@sveltejs/kit';
import type { RequestHandler } from '@sveltejs/kit';

// Maneja la solicitud GET para obtener los recibos según la cédula
export const GET: RequestHandler = async ({ url }) => {
  try {
    const cedula = url.searchParams.get('cedula');

    if (!cedula) {
      return json({ mensaje: 'Cédula es obligatoria.' }, { status: 400 });
    }

    // Consulta SQL para obtener los recibos basados en la cédula
    const [rows] = await pool.execute(
      `SELECT r.fecha, r.monto, r.metodo_pago, r.referencia_pago, CONCAT('/static/recibos/', r.id, '.pdf') AS pdfUrl
       FROM recibos r
       INNER JOIN clientes c ON r.cliente_id = c.id
       WHERE c.cedula = ?`,
      [cedula]
    );

    if (rows.length > 0) {
      return json({ recibos: rows });
    } else {
      return json({ mensaje: 'No se encontraron recibos para este cliente.' }, { status: 404 });
    }
  } catch (error) {
    console.error('Error al obtener los recibos:', error);
    return json({ mensaje: 'Error al obtener los recibos. Inténtelo de nuevo más tarde.' }, { status: 500 });
  }
};
