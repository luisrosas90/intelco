import { json } from '@sveltejs/kit';
import { pool } from '$lib/db'; 

export const GET = async () => {
  try {
    const [rows] = await pool.execute(`
      SELECT id, cliente_id, metodo_pago, monto, fecha 
      FROM recibos 
      WHERE DATE(fecha) = CURDATE()
    `);

    if (rows.length > 0) {
      return json({ success: true, recibos: rows });
    } else {
      return json({ success: true, recibos: [], message: 'No hay recibos generados hoy.' });
    }
  } catch (error) {
    console.error('Error al obtener el historial de recibos:', error);
    return json({ success: false, message: 'Error al obtener el historial de recibos.' }, { status: 500 });
  }
};
