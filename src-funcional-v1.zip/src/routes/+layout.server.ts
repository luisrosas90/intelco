// src/routes/dashboard/+layout.server.ts
export const load = async () => {
    return {
      props: {} // Devuelve las propiedades necesarias
    };
  };
  