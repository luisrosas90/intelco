<!-- src/App.svelte -->
<script lang="ts">
  import Dashboard from '../../../lib/components/Dashboard.svelte';
</script>
<!-- Layout principal con la navegación lateral y el contenido -->

<Dashboard />